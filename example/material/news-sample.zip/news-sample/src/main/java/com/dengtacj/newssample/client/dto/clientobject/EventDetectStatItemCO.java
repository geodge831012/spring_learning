package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class EventDetectStatItemCO {

    /**
     * 事件名称
     */
    String eventSource;

    /**
     * 标签数量
     */
    int eventNum;
}
