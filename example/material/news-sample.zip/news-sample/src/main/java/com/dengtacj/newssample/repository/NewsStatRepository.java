package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.*;
import com.dengtacj.newssample.infrastructure.database.info.mapper.NewsStatMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by Administrator on 2019/10/10 0010.
 */

@Slf4j
@Component
public class NewsStatRepository {
    @Autowired
    NewsStatMapper newsStatMapper;


    @Cache(expire = 600, key = "news-stat:", autoload = true, alarmTime=60, requestTimeout = 0)
    public NewsStatDataCO getNewsStatDataCache() throws ParseException{
        NewsStatDataCO newsStatDataCache = new NewsStatDataCO();
        freshTodayNewsStat(newsStatDataCache);
        freshHistoryNewsStat(newsStatDataCache);
        freshEventDetectStat(newsStatDataCache);
        freshTagNewsStat(newsStatDataCache);
        return newsStatDataCache;
    }

    void freshTodayNewsStat(NewsStatDataCO newsStatDataCache) {
        TodayNewsStatCO todayNewsStat = new TodayNewsStatCO();
        ProgressTimer progressTimer = new ProgressTimer();

        // 从数据库获取当天数据
        String today = DateUtil.date2str(new Date(), "yyyy-MM-dd");
        NewsStatDO todayNewsStatDO = newsStatMapper.getNewsStatAvgByDate(today);
        if(todayNewsStatDO == null) {
            log.info("getNewsStatByDate:" + today + " return null");
            return;
        }
        // 从数据库获取平均值
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(new Date());
        calendar.add(calendar.DATE,-7);
        Date sevenDayDate =calendar.getTime();
        String sevenDayStr = formatter.format(sevenDayDate);
        NewsStatDO avgNewsStatDO = newsStatMapper.getNewsStatAvgByDate(sevenDayStr);

        todayNewsStat.setUpdateTime(todayNewsStatDO.getUpdateTime());
        todayNewsStat.setItemList(new LinkedList<>());

        // 抓取
        TodayNewsStatItemCO importNewsStatItem = new TodayNewsStatItemCO();
        importNewsStatItem.setName("抓取");
        if(avgNewsStatDO.getImportAmount() != 0) {
            importNewsStatItem.setCurrNum(todayNewsStatDO.getImportAmount());
            double percent = todayNewsStatDO.getImportAmount() * 100 / (double)avgNewsStatDO.getImportAmount();
            if(percent > 100) percent = 100;
            importNewsStatItem.setPercent(percent);
        }
        todayNewsStat.getItemList().add(importNewsStatItem);


        // 入库
        TodayNewsStatItemCO duplicatedNewsStatItem = new TodayNewsStatItemCO();
        duplicatedNewsStatItem.setName("入库");
        int duplicatedAmount = todayNewsStatDO.getImportAmount() - todayNewsStatDO.getDuplicatedAmount();
        int avgDuplicatedAmount = avgNewsStatDO.getImportAmount() - avgNewsStatDO.getDuplicatedAmount();
        if( avgDuplicatedAmount != 0) {
            duplicatedNewsStatItem.setCurrNum(duplicatedAmount);
            double percent = duplicatedAmount * 100 / (double)avgDuplicatedAmount;
            if(percent > 100) percent = 100;
            duplicatedNewsStatItem.setPercent(percent);
        }
        todayNewsStat.getItemList().add(duplicatedNewsStatItem);


        // 标签
        TodayNewsStatItemCO tagNewsStatItem = new TodayNewsStatItemCO();
        tagNewsStatItem.setName("标签");
        if(avgNewsStatDO.getTagAmount() != 0) {
            tagNewsStatItem.setCurrNum(todayNewsStatDO.getTagAmount());
            double percent = todayNewsStatDO.getTagAmount() * 100 / (double)avgNewsStatDO.getTagAmount();
            if(percent > 100) percent = 100;
            tagNewsStatItem.setPercent(percent);
        }
        todayNewsStat.getItemList().add(tagNewsStatItem);

        // 事件发现
        TodayNewsStatItemCO eventNewsStatItem = new TodayNewsStatItemCO();
        eventNewsStatItem.setName("事件发现");
        if(avgNewsStatDO.getEventAmount() != 0) {
            eventNewsStatItem.setCurrNum(todayNewsStatDO.getEventAmount());
            double percent = todayNewsStatDO.getEventAmount() * 100 / (double)avgNewsStatDO.getEventAmount();
            if(percent > 100) percent = 100;
            eventNewsStatItem.setPercent(percent);
        }
        todayNewsStat.getItemList().add(eventNewsStatItem);

        newsStatDataCache.setTodayNewsStat(todayNewsStat);

        log.info("newsStat: freshTodayNewsStat|time:" + progressTimer.elapse());

    }

    void freshHistoryNewsStat(NewsStatDataCO newsStatDataCache) throws ParseException{
        List<HistoryNewsStatCO> historyNewsStatList = new LinkedList<>();
        ProgressTimer progressTimer = new ProgressTimer();

        // 日
        List<HistoryNewsStatDO> historyNewsStatDOListByDay = newsStatMapper.listHistoryNewsStatByDay();
        historyNewsStatList.add(convertToHistoryNewsStatCO(historyNewsStatDOListByDay, "日"));

        // 周
        List<HistoryNewsStatDO> historyNewsStatDOListByWeek = newsStatMapper.listHistoryNewsStatByWeek();
        historyNewsStatList.add(convertToHistoryNewsStatCO(historyNewsStatDOListByWeek, "周"));

        // 月
        List<HistoryNewsStatDO> historyNewsStatDOListByMonth = newsStatMapper.listHistoryNewsStatByMonth();
        historyNewsStatList.add(convertToHistoryNewsStatCO(historyNewsStatDOListByMonth, "月"));

        newsStatDataCache.setHistoryNewsStatList(historyNewsStatList);
        log.info("newsStat: freshHistoryNewsStat|time:" + progressTimer.elapse());

    }


    void freshEventDetectStat(NewsStatDataCO newsStatDataCache) {

        List<EventDetectStatCO> eventDetectStatList = new LinkedList<>();
        ProgressTimer progressTimer = new ProgressTimer();

        List<EventDetectStatDO> eventDetectStatDOList = newsStatMapper.listEventDetectStat();

        // 获取标签总数量，需要日期字符串
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date today = new Date();
        Calendar calendar = new GregorianCalendar();

        calendar.setTime(today);
        calendar.add(calendar.DATE,-3);
        Date threeDayDate =calendar.getTime();
        String threeDayStr = formatter.format(threeDayDate);

        calendar.setTime(today);
        calendar.add(calendar.DATE,-5);
        Date fiveDayDate =calendar.getTime();
        String fiveDayStr = formatter.format(fiveDayDate);

        calendar.setTime(today);
        calendar.add(calendar.DATE,-7);
        Date sevenDayDate =calendar.getTime();
        String sevenDayStr = formatter.format(sevenDayDate);


        // 3日
        EventDetectStatCO threeDayStatCO = new EventDetectStatCO();
        threeDayStatCO.setItemList(new LinkedList<>());
        threeDayStatCO.setTitle("3日");
        threeDayStatCO.setEventNum(newsStatMapper.getNewsStatSumByDate(threeDayStr).getEventAmount());
        for(EventDetectStatDO eventDetectStatDO : eventDetectStatDOList) {
            EventDetectStatItemCO itemCO = new EventDetectStatItemCO();
            itemCO.setEventNum(eventDetectStatDO.getThreeDayAmount());
            itemCO.setEventSource(eventDetectStatDO.getSourceName());
            threeDayStatCO.getItemList().add(itemCO);
        }
        eventDetectStatList.add(threeDayStatCO);


        // 5日
        EventDetectStatCO fiveDayStatCO = new EventDetectStatCO();
        fiveDayStatCO.setItemList(new LinkedList<>());
        fiveDayStatCO.setTitle("5日");
        fiveDayStatCO.setEventNum(newsStatMapper.getNewsStatSumByDate(fiveDayStr).getEventAmount());
        for(EventDetectStatDO eventDetectStatDO : eventDetectStatDOList) {
            EventDetectStatItemCO itemCO = new EventDetectStatItemCO();
            itemCO.setEventNum(eventDetectStatDO.getFiveDayAmount());
            itemCO.setEventSource(eventDetectStatDO.getSourceName());
            fiveDayStatCO.getItemList().add(itemCO);
        }
        eventDetectStatList.add(fiveDayStatCO);

        // 7日
        EventDetectStatCO sevenDayStatCO = new EventDetectStatCO();
        sevenDayStatCO.setItemList(new LinkedList<>());
        sevenDayStatCO.setTitle("7日");
        sevenDayStatCO.setEventNum(newsStatMapper.getNewsStatSumByDate(sevenDayStr).getEventAmount());
        for(EventDetectStatDO eventDetectStatDO : eventDetectStatDOList) {
            EventDetectStatItemCO itemCO = new EventDetectStatItemCO();
            itemCO.setEventNum(eventDetectStatDO.getSevenDayAmount());
            itemCO.setEventSource(eventDetectStatDO.getSourceName());
            sevenDayStatCO.getItemList().add(itemCO);
        }
        eventDetectStatList.add(sevenDayStatCO);

        newsStatDataCache.setEventDetectStatList(eventDetectStatList);
        log.info("newsStat: freshEventDetectStat|time:" + progressTimer.elapse());

    }


    void freshTagNewsStat(NewsStatDataCO newsStatDataCache) {
        List<TagNewsStatCO> tagNewsStatList = new LinkedList<>();
        ProgressTimer progressTimer = new ProgressTimer();

        // 日
        TagNewsStatDO tagNewsStatCurDay = newsStatMapper.getTagNewsStatCurDay();
        if(tagNewsStatCurDay != null) {
            tagNewsStatList.add(convertToTagNewsStatCO(tagNewsStatCurDay, "日"));
        }

        // 周
        TagNewsStatDO tagNewsStatCurWeek = newsStatMapper.getTagNewsStatCurWeek();
        if(tagNewsStatCurWeek != null) {
            tagNewsStatList.add(convertToTagNewsStatCO(tagNewsStatCurWeek, "周"));
        }


        // 月
        TagNewsStatDO tagNewsStatCurMonth = newsStatMapper.getTagNewsStatCurMonth();
        if(tagNewsStatCurMonth != null) {
            tagNewsStatList.add(convertToTagNewsStatCO(tagNewsStatCurMonth, "月"));
        }

        newsStatDataCache.setTagNewsStatList(tagNewsStatList);
        log.info("newsStat: freshTagNewsStat|time:" + progressTimer.elapse());

    }

    TagNewsStatCO convertToTagNewsStatCO(TagNewsStatDO tagNewsStatDO, String title) {
        TagNewsStatCO tagNewsStatCO = new TagNewsStatCO();
        tagNewsStatCO.setTitle(title);
        tagNewsStatCO.setSensitiveWordNum(tagNewsStatDO.getSensitiveWordsAmount());
        int total = tagNewsStatDO.getChainTagAmount() + tagNewsStatDO.getConceptTagAmount()
                + tagNewsStatDO.getDistrictsTagAmount() + tagNewsStatDO.getIndustryTagAmount()
                + tagNewsStatDO.getPeopleTagAmount() + tagNewsStatDO.getSecTagAmount()
                + tagNewsStatDO.getOrgansTagAmount();
        if(total == 0) {
            return tagNewsStatCO;
        }
        tagNewsStatCO.setTotalTagNum( total );
        tagNewsStatCO.setItemList(new LinkedList<>());
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("个股", tagNewsStatDO.getSecTagAmount(), tagNewsStatDO.getSecTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("行业", tagNewsStatDO.getIndustryTagAmount(), tagNewsStatDO.getIndustryTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("概念", tagNewsStatDO.getConceptTagAmount(), tagNewsStatDO.getConceptTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("人物", tagNewsStatDO.getPeopleTagAmount(), tagNewsStatDO.getPeopleTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("机构", tagNewsStatDO.getOrgansTagAmount(), tagNewsStatDO.getOrgansTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("地域", tagNewsStatDO.getDistrictsTagAmount(), tagNewsStatDO.getDistrictsTagAmount()*100/(double)total));
        tagNewsStatCO.getItemList().add(new TagNewsStatItemCO("产业", tagNewsStatDO.getChainTagAmount(), tagNewsStatDO.getChainTagAmount()*100/(double)total));

        return tagNewsStatCO;
    }


    HistoryNewsStatCO convertToHistoryNewsStatCO(List<HistoryNewsStatDO> historyNewsStatDOList, String title)  throws ParseException{
        HistoryNewsStatCO historyNewsStat = new HistoryNewsStatCO();
        historyNewsStat.setTitle(title);
        historyNewsStat.setItemList(new LinkedList<>());

        for(HistoryNewsStatDO historyNewsStatDO : historyNewsStatDOList) {
            HistoryNewsStatItemCO historyNewsStatItem = new HistoryNewsStatItemCO();
            historyNewsStatItem.setSpiderNum(historyNewsStatDO.getImportAmount());
            historyNewsStatItem.setAfterDupNum(historyNewsStatDO.getImportAmount() - historyNewsStatDO.getDuplicatedAmount());

            // 计算开始时间和截止时间
            if(title.equals("日")) {
                historyNewsStatItem.setStartTime(DateUtil.str2TimeSeconds(historyNewsStatDO.getDate(), "yyyy-MM-dd"));
                historyNewsStatItem.setEndTime(DateUtil.str2TimeSeconds(historyNewsStatDO.getDate(), "yyyy-MM-dd"));
            } else if(title.equals("周")) {
                String[] date = historyNewsStatDO.getDate().split("-");
                int year = Integer.parseInt(date[0]);
                int week = Integer.parseInt(date[1]);
                historyNewsStatItem.setStartTime(DateUtil.str2TimeSeconds(DateUtil.getStartDayOfWeekNo(year, week), "yyyy-MM-dd"));
                long endDay = DateUtil.str2TimeSeconds(DateUtil.getEndDayOfWeekNo(year, week), "yyyy-MM-dd");
                long today = DateUtil.getTodayStartTime().getTime()/1000;
                if( endDay > today ) {
                    historyNewsStatItem.setEndTime(today);
                } else {
                    historyNewsStatItem.setEndTime(endDay);
                }

            } else if(title.equals("月")) {
                String[] date = historyNewsStatDO.getDate().split("-");
                int year = Integer.parseInt(date[0]);
                int month = Integer.parseInt(date[1]);
                historyNewsStatItem.setStartTime(DateUtil.str2TimeSeconds(DateUtil.getFirstDayOfMonth(year, month), "yyyy-MM-dd"));
                long endDay = DateUtil.str2TimeSeconds(DateUtil.getLastDayOfMonth(year, month), "yyyy-MM-dd");
                long today = DateUtil.getTodayStartTime().getTime()/1000;
                if( endDay > today ) {
                    historyNewsStatItem.setEndTime(today);
                } else {
                    historyNewsStatItem.setEndTime(endDay);
                }
            }

            historyNewsStat.getItemList().add(historyNewsStatItem);
        }
        return historyNewsStat;
    }


}
