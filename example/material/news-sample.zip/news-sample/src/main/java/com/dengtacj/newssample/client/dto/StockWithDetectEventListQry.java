package com.dengtacj.newssample.client.dto;

import com.dengtacj.newssample.common.AppPageQuery;
import lombok.Data;

/**
 * Created by Administrator on 2019/10/15 0015.
 */

@Data
public class StockWithDetectEventListQry extends AppPageQuery {
    String eventId;
}
