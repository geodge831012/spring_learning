package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.client.api.NewsInfoServiceI;
import com.dengtacj.newssample.client.dto.Enum.RecommendNewsTypeEnum;
import com.dengtacj.newssample.client.dto.clientobject.NewsInfoCO;
import com.dengtacj.newssample.client.dto.clientobject.RecommendAnnCO;
import com.dengtacj.newssample.client.dto.clientobject.RecommendNewsCO;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsTypeDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.RecommendAnnDO;
import com.dengtacj.newssample.infrastructure.database.info.mapper.NewsInfoMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/9/29 0029.
 */

@Slf4j
@Component
public class NewsInfoRepository {

    @Autowired
    NewsInfoMapper newsInfoMapper;

    /**
     * 首先从Redis中获取，若没有从数据库中读取并更新缓存
     * 若不存在返回null
     * @param newsId
     * @return
     */
    public NewsInfoCO getByNewsId(String newsId) {
        ProgressTimer timer = new ProgressTimer();
        NewsInfoCO newsInfoCO = null;

        // 从数据库中读取
        NewsInfoDO newsInfoDO = newsInfoMapper.getByNewsId(newsId);
        if (newsInfoDO == null) {
            log.info("from db getByNewsId:" + newsId + "|" + timer.elapse());
            return  newsInfoCO;
        }
        newsInfoCO = new NewsInfoCO();
        BeanUtils.copyProperties(newsInfoDO, newsInfoCO);
        return newsInfoCO;
    }


    public Map<String, NewsInfoCO> batchGetByNewsId(List<String> newsIdList) {
        Map<String, NewsInfoCO> newsInfoMap  = new HashMap<>(newsIdList.size());
        List<NewsInfoDO> newsInfoDOList = newsInfoMapper.batchGetByNewsId(newsIdList);
        for(NewsInfoDO newsInfoDO : newsInfoDOList) {
            NewsInfoCO newsInfoCO = new NewsInfoCO();
            BeanUtils.copyProperties(newsInfoDO, newsInfoCO);
            newsInfoMap.put(newsInfoDO.getId(), newsInfoCO);
        }
        return newsInfoMap;
    }

    @Cache(expire = 240, key = "writing-news-id-list:", autoload = true, alarmTime=60, requestTimeout = 0)
    public List<String> getMachineWritingNewsIdListCache() {
        List<String> machineWritingNewsIdListCache = new LinkedList<>();

        ProgressTimer progressTimer = new ProgressTimer();
        machineWritingNewsIdListCache = newsInfoMapper.getNewsIdByType(NewsTypeDO.E_machine_writing.getCode());
        log.info("newsInfo: machineWritingNews|size:" + machineWritingNewsIdListCache.size() + "|time:" + progressTimer.elapse());

        return machineWritingNewsIdListCache;
    }

    public List<RecommendNewsCO> listRecommendNew() {
        List<RecommendNewsCO> recommendNewsList = new LinkedList<>();
        for (RecommendNewsTypeEnum newsType : RecommendNewsTypeEnum.values()) {
            RecommendNewsCO recommendNews = new RecommendNewsCO();
            String newsId = newsInfoMapper.getRecommendNewsIdByType(newsType.getCode(), 1);
            if(newsId == null) {
                continue;
            }
            NewsInfoCO newsInfo = getByNewsId(newsId);
            if(newsInfo == null) {
                continue;
            }
            recommendNews.setId(newsInfo.getId());
            recommendNews.setTitle(newsInfo.getTitle());
            recommendNews.setSummary(newsInfo.getSummary());
            recommendNews.setAttitude(newsInfo.getAttitude());
            recommendNews.setCreateTime(newsInfo.getCreateTime());
            recommendNews.setPublishTime(newsInfo.getPublishTime());
            recommendNews.setType(newsType.getMessage());
            recommendNews.setSource(newsInfo.getSource());

            recommendNewsList.add(recommendNews);
        }
        return recommendNewsList;
    }

    public List<RecommendAnnCO> listRecommendAnn() {
        List<RecommendAnnCO> recommendAnnCOList = new LinkedList<>();
        List<RecommendAnnDO> recommendAnnDOList = newsInfoMapper.listRecommendAnn(3);
        for(RecommendAnnDO recommendAnnDO : recommendAnnDOList) {
            RecommendAnnCO recommendAnnCO = new RecommendAnnCO();
            String newsId = recommendAnnDO.getSTime() + "_" + recommendAnnDO.getSId() + "_"
                    + recommendAnnDO.getEDataDbSource() + "_" + recommendAnnDO.getENewsTable();
            recommendAnnCO.setNewsId(newsId);
            recommendAnnCO.setSTime(recommendAnnDO.getSTime());
            recommendAnnCO.setTitle(recommendAnnDO.getTitle());
            recommendAnnCO.setClassName(recommendAnnDO.getClassName());

            recommendAnnCOList.add(recommendAnnCO);
        }
        return recommendAnnCOList;
    }

}
