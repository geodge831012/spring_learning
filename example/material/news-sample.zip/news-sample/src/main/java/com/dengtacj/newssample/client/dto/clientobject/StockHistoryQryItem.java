package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/22 0022.
 */

@Data
public class StockHistoryQryItem {
    /**
     * 股票代码
     */
    String dtSecCode;
    /**
     * 日期
     */
    String dateStr;
}
