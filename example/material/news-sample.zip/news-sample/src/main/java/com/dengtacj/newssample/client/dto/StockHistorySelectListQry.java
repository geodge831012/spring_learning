package com.dengtacj.newssample.client.dto;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/18 0018.
 */

@Data
public class StockHistorySelectListQry {
    /**
     * 日期 例如：2019-10-17
     */
    String dateStr;
}
