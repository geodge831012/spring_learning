package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class NewsTagDO {
    String newsId;
    String relatedPeople;          // 人物
    String relatedOrgans;          // 机构
    String relatedDistricts;       // 地域
    String relatedSecCode;        // 股票代码
    String relatedEventId;        // 事件ID
    String relatedPlateConcept;   // 概念
    String relatedPlateDistricts; // 相关地域
    String relatedPlateIndustry;  // 行业
    String relatedChain;           // 产业链
    String mainKeyword;           // 主关键词
    String viceKeyword;           // 副关键词
}
