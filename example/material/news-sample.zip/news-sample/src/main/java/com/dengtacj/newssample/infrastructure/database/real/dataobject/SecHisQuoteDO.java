package com.dengtacj.newssample.infrastructure.database.real.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Data
public class SecHisQuoteDO {
    /**
     * 股票代码
     */
    String secCode;

    /**
     * 交易日
     */
    Long tradingDay;
    /**
     * 前复权收盘价格
     */
    float closePriceBefore;
}
