package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Mapper
public interface DetectEventMapper {

    /**
     * 查询事件列表
     * @return
     */
    public List<DetectEventDO> listEventByDate(String beginTime);

    /**
     * 查询事件对应的标签
     * @return
     */
    public List<EventKeywordDO> listKeywordByEventId(String eventId);

    /**
     * 查询事件对应的资讯
     * @return
     */
    public List<String> listNewsIdByEventId(String eventId);

    /**
     * 查询事件对应的股票
     * @return
     */
    public List<StockWithScoreDO> listStockCodeByEventId(String eventId);

    /**
     * 获取所有的事件信息
     * @return
     */
    List<EventInfoDO> listAllEvent();

}
