package com.dengtacj.newssample.infrastructure.database.cls.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Data
public class LianSubjectDO {
    String articleId;
    String subjectId;
    String subjectName;
}
