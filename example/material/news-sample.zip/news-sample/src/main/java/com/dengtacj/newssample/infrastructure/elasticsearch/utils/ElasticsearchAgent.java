package com.dengtacj.newssample.infrastructure.elasticsearch.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.elasticsearch.dataobject.RelatedNewsDO;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.ResponseException;
import org.elasticsearch.client.RestClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/10/11 0011.
 */

@Slf4j
@Component
public class ElasticsearchAgent {

    @Autowired
    RestClient lowLevelClient;


    public JSONObject search(String queryString, String endpoint) {
        ProgressTimer timer = new ProgressTimer();
        log.info(queryString);
        JSONObject retObject = null;
        Map<String, String> params = Collections.emptyMap();
        HttpEntity entity = new NStringEntity(queryString, ContentType.APPLICATION_JSON);
        String debugStr;
        try {
            Response response = lowLevelClient.performRequest("GET", endpoint, params, entity);
            System.out.println();
            if(response.getStatusLine().getStatusCode() != 200) {
                log.error("response error code:" + response.getStatusLine().getStatusCode());
                return retObject;
            }
            String responseBody = null;
            responseBody = EntityUtils.toString(response.getEntity());
            JSONObject jsonObject = JSON.parseObject(responseBody);
            retObject = jsonObject.getJSONObject("hits");
            log.info(responseBody);
        } catch (ResponseException e){
            log.error("ResponseException: ", e);
        } catch (IOException e) {
            log.error("IOException: ", e);
        }

        log.info("search|" + endpoint + "|" + timer.elapse() + "ms");
        return retObject;
    }
}
