package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.NewsFlashServiceI;
import com.dengtacj.newssample.client.dto.NewsFlashListQry;
import com.dengtacj.newssample.client.dto.clientobject.NewsFlashCO;
import com.dengtacj.newssample.common.ErrorCode;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.utils.PageUtil;
import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianArticleDO;
import com.dengtacj.newssample.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Slf4j
@Service
public class NewsFlashImpl implements NewsFlashServiceI {

    @Autowired
    NewsFlashRepository newsFlashRepository;

    @Value("${news.common.pageSize}")
    int pageSize;


    public MultiResponse<NewsFlashCO> listNewsFlash(NewsFlashListQry newsFlashListQry) {

        try {
            // 分页
            PageUtil<LianArticleDO> pageUtil = new PageUtil<>();
            List<LianArticleDO> pagedNewsFlashCO = pageUtil.getCurrentPageByApp(LianArticleDO.class.getName(), "getId",
                    newsFlashRepository.getArticleDOList(), newsFlashListQry.getDirection(), newsFlashListQry.getStartId(), pageSize);


            // 格式转换，填写标签数据
            List<NewsFlashCO> newsFlashCOList = new LinkedList<>();
            Map<String, List<String>> articleSubjectMap = newsFlashRepository.getArticleSubjectMap();
            for (LianArticleDO lianArticleDO : pagedNewsFlashCO) {
                NewsFlashCO newsFlashCO = new NewsFlashCO();
                newsFlashCO.setArticleId(lianArticleDO.getId());
                newsFlashCO.setContent(lianArticleDO.getContent());
                newsFlashCO.setPublishTime(lianArticleDO.getCtime());
                newsFlashCO.setImportanceLevel(lianArticleDO.getRecommend());
                newsFlashCO.setSubjectList(articleSubjectMap.get(newsFlashCO.getArticleId()));
                newsFlashCOList.add(newsFlashCO);
            }

            return MultiResponse.of(newsFlashCOList, pageUtil.isHaveMore(), pageUtil.getiTotal());
        } catch (Exception e) {
            log.error("exception:", e);
        }
        return MultiResponse.buildFailure(ErrorCode.E_Node_unknownError);
    }
}
