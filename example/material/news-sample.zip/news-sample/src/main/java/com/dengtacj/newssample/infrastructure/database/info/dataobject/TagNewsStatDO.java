package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/10 0010.
 */

@Data
public class TagNewsStatDO {
    int sensitiveWordsAmount;
    int secTagAmount;
    int peopleTagAmount;
    int organsTagAmount;
    int districtsTagAmount;
    int conceptTagAmount;
    int industryTagAmount;
    int chainTagAmount;
}
