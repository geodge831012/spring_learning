package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.HotspotEventServiceI;
import com.dengtacj.newssample.client.dto.Enum.HisQuoteQueryEnum;
import com.dengtacj.newssample.client.dto.StockHistoryQuoteListQry;
import com.dengtacj.newssample.client.dto.StockHistorySelectListQry;
import com.dengtacj.newssample.client.dto.clientobject.StockHistoryQryItem;
import com.dengtacj.newssample.client.dto.clientobject.StockHistoryQuoteCO;
import com.dengtacj.newssample.client.dto.clientobject.StockHistorySelectCO;
import com.dengtacj.newssample.common.ErrorCode;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.repository.SecHisQuoteRepository;
import com.dengtacj.newssample.repository.SecHisQuoteRepositoryWrapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/10/17 0017.
 */

@Slf4j
@Service
public class HotspotEventServiceImpl implements HotspotEventServiceI {

    @Autowired
    SecHisQuoteRepositoryWrapper secHisQuoteRepository;


    private int getCurrTradingDate(String dateStr) throws ParseException {
        // 获取请求日期最近的交易日期
        int currIdx = -1;
        long reqDate = DateUtil.str2TimeSeconds(dateStr, "yyyy-MM-dd");
        for(int i=0; i< secHisQuoteRepository.getTradingDateListCache().size(); i++) {
            long date = secHisQuoteRepository.getTradingDateListCache().get(i);

            if(date == reqDate) {
                currIdx = i;
                break;
            } else if(date < reqDate) {
                currIdx = i;
                break;
            }
        }

        if(currIdx < 0) {
            log.error("error: req.getDateStr: " + dateStr);
            return currIdx;
        }
        Long currDate = secHisQuoteRepository.getTradingDateListCache().get(currIdx);
        log.info("getCurrDate:" +  DateUtil.timeSeconds2str(currDate, "yyyy-MM-dd"));
        return currIdx;
    }

    long [] computeDateRange(HisQuoteQueryEnum queryType, int currIdx, String currDateStr) {
        // 检查当前日期是否是交易日
        boolean isTradingDate = false;
        Long currDate = secHisQuoteRepository.getTradingDateListCache().get(currIdx);
        if(currDateStr.equals(DateUtil.timeSeconds2str(currDate, "yyyy-MM-dd"))) {
            isTradingDate = true;
        }

        // 计算开始日期和截止日志和当前日期序号的偏离量
        int beginDelta = 0;
        int endDateDelta = 0;
        switch (queryType) {
            case E_Three_day_before:
                if(isTradingDate) {
                    beginDelta = 3;
                    endDateDelta = 1;
                } else {
                    beginDelta = 2;
                    endDateDelta = 0;
                }
                break;
            case E_today:
                beginDelta = 1;
                endDateDelta = 0;
                break;
            case E_three_day_after:
                beginDelta = 0;
                endDateDelta = -3;
                break;
            case E_five_day_after:
                beginDelta = 0;
                endDateDelta = -5;
                break;
            default:
                log.error("error: req.getQueryType: " + queryType.getValue());
        }

        // 获取开始日期和截止日期
        long beginDate = 0;
        int beginIdx = currIdx + beginDelta;
        if(beginIdx >= 0 && beginIdx < secHisQuoteRepository.getTradingDateListCache().size()) {
            beginDate = secHisQuoteRepository.getTradingDateListCache().get(beginIdx);
        }
        long endDate = 0;
        int endIdx = currIdx + endDateDelta;
        if(endIdx >= 0 && endIdx < secHisQuoteRepository.getTradingDateListCache().size()) {
            endDate = secHisQuoteRepository.getTradingDateListCache().get(endIdx);
        }
        return new long[]{beginDate, endDate};
    }


    public MultiResponse<StockHistorySelectCO> listStockHistorySelectQry(StockHistorySelectListQry req){
        List<StockHistorySelectCO> stockHistorySelectList = new LinkedList<>();
        try {
            int currIdx = getCurrTradingDate(req.getDateStr());
            if(currIdx < 0) {
                return MultiResponse.buildFailure(ErrorCode.E_Node_requestParamError);
            }

            for(HisQuoteQueryEnum queryType : HisQuoteQueryEnum.values()) {
                StockHistorySelectCO stockHistorySelectCO = new StockHistorySelectCO();
                stockHistorySelectCO.setQueryType(queryType.getValue());
                // 计算开始日期和截止日期
                long[] dateRange = computeDateRange(queryType, currIdx, req.getDateStr());
                long beginDate = dateRange[0];
                long endDate = dateRange[1];
                if(beginDate == 0 || endDate == 0) {
                    stockHistorySelectCO.setAvailable(false);
                    log.info("queryType:" + queryType.getValue() + "|beginDate: " + beginDate + "|endDate:" + endDate);
                } else {
                    stockHistorySelectCO.setAvailable(true);
                    log.info("queryType:" + queryType.getValue() + "|beginDate: " + DateUtil.timeSeconds2str(beginDate, "yyyy-MM-dd") + "|endDate:" + DateUtil.timeSeconds2str(endDate, "yyyy-MM-dd"));
                }
                stockHistorySelectList.add(stockHistorySelectCO);
            }
        } catch (Exception e) {
            log.error("exception:", e);
            return MultiResponse.buildFailure(ErrorCode.E_Node_requestParamError);
        }
        return MultiResponse.ofWithoutTotal(stockHistorySelectList);
    }

    public MultiResponse<StockHistoryQuoteCO> listStockHistoryQuoteQry(StockHistoryQuoteListQry req) {
        try {
            // 获取收盘数据
            List<StockHistoryQuoteCO> stockHistoryQuoteList = new LinkedList<>();
            for(StockHistoryQryItem item : req.getStockHisList()) {

                // 获取当前日期最近的交易日的序号
                int currIdx = getCurrTradingDate(item.getDateStr());
                if(currIdx < 0) {
                    return MultiResponse.buildFailure(ErrorCode.E_Node_requestParamError);
                }

                // 计算开始日期和截止日期
                long[] dateRange = computeDateRange(HisQuoteQueryEnum.convert(req.getQueryType()), currIdx, item.getDateStr());
                long beginDate = dateRange[0];
                long endDate = dateRange[1];
                if(beginDate == 0 || endDate == 0) {
                    log.error("error: beginDate:" + beginDate  + " endDate:" + endDate);
                    return MultiResponse.buildFailure(ErrorCode.E_Node_notExistError);
                }
                log.info("beginDate: " + DateUtil.timeSeconds2str(beginDate, "yyyy-MM-dd") + "|endDate:" + DateUtil.timeSeconds2str(endDate, "yyyy-MM-dd"));


                String stockCode = item.getDtSecCode().trim();
                float rate = 0.0f;
                StockHistoryQuoteCO stockHistoryQuote = new StockHistoryQuoteCO();
                Map<Long, Float> hisQuoteMap = secHisQuoteRepository.getSecHisQuoteCache().get(stockCode);
                if(hisQuoteMap == null) {
                    log.warn("dtSecCode:" + stockCode + " not exist");
                } else if(hisQuoteMap.get(endDate) == null) {
                    log.warn("dtSecCode:" + stockCode + " endDate: " + endDate + " not exist");
                } else if(hisQuoteMap.get(beginDate) == null) {
                    log.warn("dtSecCode:" + stockCode + " beginDate: " + beginDate + " not exist");
                } else {
                    rate = (hisQuoteMap.get(endDate) - hisQuoteMap.get(beginDate))/hisQuoteMap.get(beginDate) * 100;
                }
                NumberFormat formatter = new DecimalFormat("0.00");
                stockHistoryQuote.setRate(formatter.format(rate));
                stockHistoryQuote.setDtSecCode(stockCode);
                stockHistoryQuote.setDateStr(item.getDateStr());
                stockHistoryQuoteList.add(stockHistoryQuote);
            }
            stockHistoryQuoteList.sort(Comparator.comparing(StockHistoryQuoteCO::getRate).reversed());
            return MultiResponse.ofWithoutTotal(stockHistoryQuoteList);

        } catch (Exception e) {
            log.error("exception:", e);
            return MultiResponse.buildFailure(ErrorCode.E_Node_unknownError);
        }

    }
}
