package com.dengtacj.newssample.client.dto.Enum;

/**
 * @author LC
 * @date 2018/5/21
 */
public enum RecommendNewsTypeEnum {

    E_MOST_CLICK ("most_click", "最多查看"),
    E_MOST_REPRINTED ("most_reprinted", "最多转载"),
    E_MOST_HOT ("most_multiple", "综合最热");

    private final String code;
    private final String message;



    RecommendNewsTypeEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }


    public String getCode() {
        return code;
    }


    public String getMessage() {
        return message;
    }

}
 