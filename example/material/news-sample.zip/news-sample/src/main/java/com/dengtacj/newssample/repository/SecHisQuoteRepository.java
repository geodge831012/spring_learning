package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.real.dataobject.SecHisQuoteDO;
import com.dengtacj.newssample.infrastructure.database.real.mapper.DailyQuoteMapper;
import com.jarvis.cache.annotation.Cache;
import com.jarvis.cache.annotation.CacheDelete;
import com.jarvis.cache.annotation.CacheDeleteKey;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Administrator on 2019/10/17 0017.
 */

@Slf4j
@Component
public class SecHisQuoteRepository {

    @Autowired
    DailyQuoteMapper dailyQuoteMapper;


    /**
     * Redis 缓存主要解决服务重启后的缓存数据加载慢的问题
     * @return
     */
    @Cache(expire = 0, key = "sec-daily-quote:", lockExpire=120)
    public Map<String, Map<Long, Float>> getSecHisQuoteMap() {
        Map<String, Map<Long, Float>> secHisQuote = new HashMap<>();
        ProgressTimer progressTimer = new ProgressTimer();

        // 遍历加载一年的日收盘价格
        Long nowMillis = System.currentTimeMillis();
        Long monthMillis = 30 * 24 * 60 * 60 * 1000L;

        String endDate = DateUtil.date2str(new Date(nowMillis), "yyyy-MM-dd");
        for(int i=1; i<=12; i++){
            String beginDate = DateUtil.date2str(new Date(nowMillis - i * monthMillis), "yyyy-MM-dd");
            List<SecHisQuoteDO> secHisQuoteDOList = dailyQuoteMapper.listQuoteByTradingDay(beginDate, endDate);
            endDate = beginDate;
            log.info("listQuoteByTradingDay:begin:" + beginDate + "|end:" + endDate );
            for(SecHisQuoteDO secHisQuoteDO : secHisQuoteDOList) {
                Map<Long, Float> hisQuoteMap = secHisQuote.computeIfAbsent(secHisQuoteDO.getSecCode(), k->new ConcurrentHashMap<>());
                hisQuoteMap.put(secHisQuoteDO.getTradingDay(), secHisQuoteDO.getClosePriceBefore());
            }
        }
        log.info("quote: secHisQuoteCache|size:" + secHisQuote.size() + "|time:" + progressTimer.elapse());
        return secHisQuote;
    }

    @Cache(expire = 0, key = "sec-trading-date:")
    public ArrayList<Long> getTradingDateList() {
        ProgressTimer progressTimer = new ProgressTimer();
        Long now = System.currentTimeMillis();
        Long beginTime = now - 365 * 24 * 60 * 60 * 1000L;  // 只访问最近一年的数据
        String beginTimeStr = DateUtil.date2str(new Date(beginTime), "yyyy-MM-dd");

        ArrayList<Long> tradingDateListCache = dailyQuoteMapper.listTradingDay(beginTimeStr);
        log.info("quote: tradingDateListCache|size:" + tradingDateListCache.size() + "|time:" + progressTimer.elapse());
        return tradingDateListCache;
    }

    @CacheDelete({ @CacheDeleteKey(value = "sec-daily-quote:", condition = "#retVal") })
    public boolean cleanSecHisQuoteMap() {
        return true;
    }

    @CacheDelete({ @CacheDeleteKey(value = "sec-trading-date:", condition = "#retVal") })
    public boolean cleanTradingDateList() {
        return true;
    }

}
