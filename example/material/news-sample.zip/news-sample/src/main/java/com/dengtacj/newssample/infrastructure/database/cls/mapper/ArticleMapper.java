package com.dengtacj.newssample.infrastructure.database.cls.mapper;

import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianArticleDO;
import com.jarvis.cache.annotation.Cache;

import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

public interface ArticleMapper {
    /**
     *
     * @param createTime 大于该时间的所有记录，Unix时间戳（s）
     * @return
     */
    List<LianArticleDO> list(Long createTime);
}
