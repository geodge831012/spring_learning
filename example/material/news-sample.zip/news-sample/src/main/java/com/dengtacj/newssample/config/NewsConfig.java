package com.dengtacj.newssample.config;

import com.alibaba.fastjson.JSON;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Component
public class NewsConfig {
    @Value("${news.machineWriting.source}")
    String sourceJsonStr;

    List<NewsWritingType> newsWritingTypeList = null;

    public List<NewsWritingType> getNewsWritingTypeList() {
        if(newsWritingTypeList == null) {
            newsWritingTypeList = JSON.parseArray(sourceJsonStr,  NewsWritingType.class);
        }
        return newsWritingTypeList;
    }
}
