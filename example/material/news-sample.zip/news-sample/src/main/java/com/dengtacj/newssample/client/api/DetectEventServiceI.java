package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.DetectEventListQry;
import com.dengtacj.newssample.client.dto.NewsWithDetectEventListQry;
import com.dengtacj.newssample.client.dto.StockWithDetectEventListQry;
import com.dengtacj.newssample.client.dto.clientobject.DetectEventCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsOfEventCO;
import com.dengtacj.newssample.client.dto.clientobject.StockOfEventCO;
import com.dengtacj.newssample.common.MultiResponse;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

public interface DetectEventServiceI {
    /**
     * 获取事件列表
     * @return
     */
    public MultiResponse<DetectEventCO> listDetectEventQry(DetectEventListQry req);

    /**
     * 获取事件相关的资讯列表
     * @return
     */
    public MultiResponse<NewsOfEventCO> listNewsOfDetectEventQry(NewsWithDetectEventListQry req);

    /**
     * 获取事件相关的股票列表
     * @return
     */
    public MultiResponse<StockOfEventCO> listStockOfDetectEventQry(StockWithDetectEventListQry req);
}
