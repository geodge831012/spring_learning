package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * Created by Administrator on 2019/10/10 0010.
 */

@Mapper
public interface NewsStatMapper {

    NewsStatDO getNewsStatSumByDate(String beginTime);

    NewsStatDO getNewsStatAvgByDate(String beginTime);

    List<HistoryNewsStatDO> listHistoryNewsStatByDay();

    List<HistoryNewsStatDO> listHistoryNewsStatByWeek();

    List<HistoryNewsStatDO> listHistoryNewsStatByMonth();

    TagNewsStatDO getTagNewsStatCurDay();

    TagNewsStatDO getTagNewsStatCurWeek();

    TagNewsStatDO getTagNewsStatCurMonth();

    List<EventDetectStatDO> listEventDetectStat();

}
