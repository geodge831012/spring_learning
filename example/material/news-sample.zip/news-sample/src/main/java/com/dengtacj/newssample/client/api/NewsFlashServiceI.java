package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.NewsFlashListQry;
import com.dengtacj.newssample.client.dto.clientobject.NewsFlashCO;
import com.dengtacj.newssample.common.MultiResponse;

/**
 * Created by Administrator on 2019/9/23 0023.
 */

public interface NewsFlashServiceI {
    public MultiResponse<NewsFlashCO> listNewsFlash(NewsFlashListQry newsFlashListQry);

}
