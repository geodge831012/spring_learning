package com.dengtacj.newssample.client.dto;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

public class RecommendAnnListQry {
}
