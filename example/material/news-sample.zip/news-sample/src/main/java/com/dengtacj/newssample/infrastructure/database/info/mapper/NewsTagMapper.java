package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.EventInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsTagDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.StockInfoDO;
import com.jarvis.cache.annotation.Cache;
import com.jarvis.cache.annotation.Magic;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Mapper
public interface NewsTagMapper {
    /**
     * 获取资讯的相关标签
     * @param newsId
     * @return
     */
    NewsTagDO getNewsTags(String newsId);

    /**
     * 批量获取资讯的相关标签
     * @param newsIdList
     * @return
     */
    @Cache(expire = 3600, expireExpression = "null == #retVal ? 60: 3600",
            key = "'news-tag:' + #args[0]",
            magic = @Magic(key = "'news-tag:' + #retVal.newsId", iterableArgIndex = 0))
    List<NewsTagDO> batchGetNewsTags(@Param("newsIdList") List<String> newsIdList);



}
