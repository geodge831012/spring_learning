package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.NewsInfoServiceI;
import com.dengtacj.newssample.client.dto.*;
import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.ErrorCode;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.SingleResponse;
import com.dengtacj.newssample.repository.NewsInfoRepository;
import com.dengtacj.newssample.repository.NewsSearchRepository;
import com.dengtacj.newssample.repository.NewsTagRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * Created by Administrator on 2019/10/9 0009.
 */

@Service
public class NewsInfoImpl implements NewsInfoServiceI {

    @Autowired
    NewsInfoRepository newsInfoRepository;

    @Autowired
    NewsTagRepository newsTagRepository;

    @Autowired
    NewsSearchRepository newsSearchRepository;

    /**
     * 获取资讯详情
     * @return
     */
    @Override
    public SingleResponse<NewsInfoCO> getNewsInfoQry(NewsInfoGetQry req) {
        NewsInfoCO newsInfoCO = newsInfoRepository.getByNewsId(req.getNewsId());
        if(newsInfoCO == null) {
            SingleResponse.buildFailure(ErrorCode.E_Node_notExistError);
        }
        return SingleResponse.of(newsInfoCO);
    }

    /**
     * 获取资讯标签
     * @return
     */
    @Override
    public SingleResponse<NewsTagCO> getNewsTagQry(NewsTagGetQry req){
        NewsTagCO newsTagCO = newsTagRepository.getNewsTag(req.getNewsId());
        if(newsTagCO == null) {
            SingleResponse.buildFailure(ErrorCode.E_Node_notExistError);
        }
        return SingleResponse.of(newsTagCO);
    }

    /**
     * 获取资讯相关资讯
     * @return
     */
    @Override
    public MultiResponse<RelatedNewsCO> listNewsRelatedQry(NewsRelatedListQry req){
        return MultiResponse.ofWithoutTotal(newsSearchRepository.listRelatedNews(req.getNewsId()));
    }


    /**
     * 获取推荐资讯列表
     * @return
     */
    public MultiResponse<RecommendNewsCO> listRecommendNewsQry(RecommendNewListQry req) {
        return MultiResponse.ofWithoutTotal(newsInfoRepository.listRecommendNew());
    }

    /**
     * 获取推荐公告列表
     * @return
     */
    public MultiResponse<RecommendAnnCO> listRecommendAnnQry(RecommendAnnListQry req) {
        return MultiResponse.ofWithoutTotal(newsInfoRepository.listRecommendAnn());
    }
}
