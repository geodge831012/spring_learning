package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class NewsTagCO {
    List<TagInfoCO> relatedPeople;          // 人物
    List<TagInfoCO> relatedOrgans;          // 机构
    List<TagInfoCO> relatedDistricts;       // 地域
    List<TagInfoCO> relatedSec;            // 股票
    List<TagInfoCO> relatedEvent;          // 事件
    List<TagInfoCO> relatedPlateConcept;   // 概念
    List<TagInfoCO> relatedPlateDistricts; // 相关地域
    List<TagInfoCO> relatedPlateIndustry;  // 行业
    List<TagInfoCO> relatedChain;           // 产业链
    List<TagInfoCO> relatedKeyword;         // 关键词
}
