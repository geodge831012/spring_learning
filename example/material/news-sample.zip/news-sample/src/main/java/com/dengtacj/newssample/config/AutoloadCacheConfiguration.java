package com.dengtacj.newssample.config;

import com.jarvis.cache.ICacheManager;
import com.jarvis.cache.autoconfigure.AutoloadCacheProperties;
import com.jarvis.cache.clone.ICloner;
import com.jarvis.cache.map.MapCacheManager;
import com.jarvis.cache.redis.AbstractRedisCacheManager;
import com.jarvis.cache.redis.JedisClusterCacheManager;
import com.jarvis.cache.redis.SpringRedisCacheManager;
import com.jarvis.cache.serializer.CompressorSerializer;
import com.jarvis.cache.serializer.FastjsonSerializer;
import com.jarvis.cache.serializer.ISerializer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.jedis.JedisClusterConnection;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisConnectionUtils;
import redis.clients.jedis.JedisCluster;


@Slf4j
@Configuration
public class AutoloadCacheConfiguration {

    // @Bean
    /**
     * 默认只支持{@link JedisClusterCacheManager}<br>
     *
     * @param config
     * @param serializer
     * @param connectionFactory
     * @return
     */
    @Bean
    @ConditionalOnMissingBean(ICacheManager.class)
    @ConditionalOnBean(JedisConnectionFactory.class)
    public ICacheManager autoloadCacheCacheManager(AutoloadCacheProperties config, ISerializer<Object> serializer,
                                                   JedisConnectionFactory connectionFactory) {
        return createRedisCacheManager(config, serializer, connectionFactory);
    }

    private ICacheManager createRedisCacheManager(AutoloadCacheProperties config, ISerializer<Object> serializer, JedisConnectionFactory connectionFactory) {
        RedisConnection redisConnection = null;
        try {
            redisConnection = connectionFactory.getConnection();
            AbstractRedisCacheManager cacheManager = null;
            if (redisConnection instanceof JedisClusterConnection) {
                JedisClusterConnection redisClusterConnection = (JedisClusterConnection) redisConnection;
                // 优先使用JedisCluster; 因为JedisClusterConnection 批量处理，需要使用JedisCluster
                JedisCluster jedisCluster = redisClusterConnection.getNativeConnection();
                cacheManager = new JedisClusterCacheManager(jedisCluster, serializer);
            } else {
                cacheManager = new SpringRedisCacheManager(connectionFactory, serializer);
            }
            // 根据需要自行配置
//            cacheManager.setHashExpire(config.getJedis().getHashExpire());
            return cacheManager;
        } catch (Throwable e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            RedisConnectionUtils.releaseConnection(redisConnection, connectionFactory, true);
        }
    }

    /**
     * 大于16k对内容进行压缩
     * @return
     */
    @Bean
    public ISerializer<Object> autoloadCacheSerializer() {
        return new CompressorSerializer(new FastjsonSerializer());
    }
}
