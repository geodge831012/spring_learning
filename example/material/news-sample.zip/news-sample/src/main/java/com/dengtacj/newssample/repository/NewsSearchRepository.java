package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.client.dto.clientobject.NewsInfoCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsTagCO;
import com.dengtacj.newssample.client.dto.clientobject.RelatedNewsCO;
import com.dengtacj.newssample.client.dto.clientobject.TagInfoCO;
import com.dengtacj.newssample.infrastructure.elasticsearch.NewsSearchTunnel;
import com.dengtacj.newssample.infrastructure.elasticsearch.dataobject.RelatedNewsDO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.swing.text.html.parser.Entity;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

@Component
public class NewsSearchRepository {
    @Autowired
    NewsSearchTunnel newsSearchTunnel;

    @Autowired
    NewsTagRepository newsTagRepository;

    @Autowired
    NewsInfoRepository newsInfoRepository;

    public List<RelatedNewsCO> listRelatedNews(String newsId) {

        List<RelatedNewsCO> relatedNewsList = new LinkedList<>();

        // 获取资讯内容
        NewsInfoCO newsInfoCO = newsInfoRepository.getByNewsId(newsId);

        // 查询新闻对应的关键词
        NewsTagCO newsTagCO = newsTagRepository.getNewsTag(newsId);
        if(newsTagCO == null || newsInfoCO == null) {
            return relatedNewsList;
        }

        List<String> keyWordList = new LinkedList<>();
        for(TagInfoCO tagInfoCO : newsTagCO.getRelatedKeyword()) {
            keyWordList.add(tagInfoCO.getName());
        }
        if(keyWordList.isEmpty()) {
            return relatedNewsList;
        }
        String keyWords = String.join(" ", keyWordList);


        // 搜索相关新闻
        List<RelatedNewsDO> relatedNewsDOList = newsSearchTunnel.listRelatedNews(newsInfoCO.getTitle(), keyWords);
        for(RelatedNewsDO relatedNewsDO : relatedNewsDOList) {
            RelatedNewsCO relatedNewsCO = new RelatedNewsCO();
            BeanUtils.copyProperties(relatedNewsDO, relatedNewsCO);
            relatedNewsList.add(relatedNewsCO);
        }
        return relatedNewsList;
    }

}
