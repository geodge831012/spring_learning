package com.dengtacj.newssample.client.dto.Enum;

/**
 * Created by Administrator on 2019/10/17 0017.
 */

public enum HisQuoteQueryEnum {

    E_Three_day_before (-3), // 事前3天
    E_today (0),             // "当日"
    E_three_day_after (3),   // 事后3天
    E_five_day_after (5);    // 事后5天

    private final int value;


    HisQuoteQueryEnum(int value) {
        this.value = value;
    }

    public static HisQuoteQueryEnum convert(int value) {
        for(HisQuoteQueryEnum v : values()) {
            if(v.value == value) {
                return v;
            }
        }
        return null;
    }

    public int getValue() {
        return this.value;
    }


}
