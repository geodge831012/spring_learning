package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Data
public class StockOfEventCO {
    private String code;

    private String name;

    private Integer count;

    private Integer similar;
}
