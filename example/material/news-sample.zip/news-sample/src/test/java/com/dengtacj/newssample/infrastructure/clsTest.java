package com.dengtacj.newssample.infrastructure;

import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianArticleDO;
import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianSubjectDO;
import com.dengtacj.newssample.infrastructure.database.cls.mapper.ArticleMapper;
import com.dengtacj.newssample.infrastructure.database.cls.mapper.SubjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class clsTest {

    @Autowired
    ArticleMapper articleMapper;

    @Autowired
    SubjectMapper subjectMapper;

    @Test
    public void listArticle() {
        List<LianArticleDO> articleDOList = articleMapper.list(1566576L);
    }

    @Test
    public void listSubject() {
        List<LianSubjectDO> articleDOList = subjectMapper.list(1566576000L);
    }

}
