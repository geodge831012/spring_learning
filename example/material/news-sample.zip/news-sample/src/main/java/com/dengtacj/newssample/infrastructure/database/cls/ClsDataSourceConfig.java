package com.dengtacj.newssample.infrastructure.database.cls;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

@Configuration
@MapperScan(basePackages = "com.dengtacj.newssample.infrastructure.database.cls.mapper", sqlSessionTemplateRef  = "clsSqlSessionTemplate")
public class ClsDataSourceConfig {

    @Bean(name = "clsDataSource")
    @ConfigurationProperties(prefix = "spring.datasource.cls")
    public DataSource clsDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "clsSqlSessionFactory")
    public SqlSessionFactory clsSqlSessionFactory(@Qualifier("clsDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath:mybatis/mapper/cls/*.xml"));
        bean.setConfigLocation(new PathMatchingResourcePatternResolver().getResource("classpath:mybatis/mybatis-config.xml"));
        bean.setTypeAliasesPackage("com.dengtacj.newssample.infrastructure.database.cls.dataobject");
        return bean.getObject();
    }

    @Bean(name = "clsTransactionManager")
    public DataSourceTransactionManager clsTransactionManager(@Qualifier("clsDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "clsSqlSessionTemplate")
    public SqlSessionTemplate clsSqlSessionTemplate(@Qualifier("clsSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

}
