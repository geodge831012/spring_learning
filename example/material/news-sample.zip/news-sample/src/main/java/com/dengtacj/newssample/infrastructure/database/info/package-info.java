/**
 * 资讯平台数据库
 */
package com.dengtacj.newssample.infrastructure.database.info;