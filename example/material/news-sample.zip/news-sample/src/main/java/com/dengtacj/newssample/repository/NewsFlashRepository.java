package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianArticleDO;
import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianSubjectDO;
import com.dengtacj.newssample.infrastructure.database.cls.mapper.ArticleMapper;
import com.dengtacj.newssample.infrastructure.database.cls.mapper.SubjectMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.*;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Slf4j
@Component
public class NewsFlashRepository {

    /**
     * 每篇快讯的标签数量不能超过3个
     */
    private final int MAX_SUBJECT_NUM = 3;

    @Autowired
    ArticleMapper articleMapper;

    @Autowired
    SubjectMapper subjectMapper;


    /**
     * 获取文章列表，刷新时间间隔为expire-alarmTime
     */
    @Cache(expire = 240, key = "flash-news:", autoload = true, alarmTime=60, requestTimeout = 0)
    public List<LianArticleDO> getArticleDOList() throws ParseException{

        // 只获取当天数据
        String today = DateUtil.date2str(new Date(), "yyyy-MM-dd");
        Long beginTime = DateUtil.str2TimeSeconds(today, "yyyy-MM-dd");
        ProgressTimer progressTimer = new ProgressTimer();

        // 从数据库读取数据
        List<LianArticleDO> articleDOList = articleMapper.list(beginTime);
        log.info("flash: articleDOList| size:" + articleDOList.size() + "|time:" + progressTimer.elapse());
        return articleDOList;
    }

    /**
     * 获取文章标签
     */
    @Cache(expire = 240, key = "flash-subject:", autoload = true, alarmTime=60, requestTimeout = 0)
    public Map<String, List<String>> getArticleSubjectMap() throws ParseException{

        // 只获取当天数据
        String today = DateUtil.date2str(new Date(), "yyyy-MM-dd");
        Long beginTime = DateUtil.str2TimeSeconds(today, "yyyy-MM-dd");
        ProgressTimer progressTimer = new ProgressTimer();

        // 从数据库获取数据，并转化为map类型
        List<LianSubjectDO> lianSubjectDOList = subjectMapper.list(beginTime);
        Map<String, List<String>> articleSubjectMap = new HashMap<>();
        for(LianSubjectDO lianSubjectDO : lianSubjectDOList) {
            List<String> subjectNameList = articleSubjectMap.computeIfAbsent(lianSubjectDO.getArticleId(), k->new LinkedList<String>());
            if(subjectNameList.size() >= MAX_SUBJECT_NUM) {
                continue;
            }
            subjectNameList.add(lianSubjectDO.getSubjectName());
        }
        log.info("flash: articleSubjectMap:" + articleSubjectMap.size() + "|time:" + progressTimer.elapse());
        return articleSubjectMap;
    }
}
