package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.StockHistoryQuoteListQry;
import com.dengtacj.newssample.client.dto.StockHistorySelectListQry;
import com.dengtacj.newssample.client.dto.clientobject.StockHistoryQuoteCO;
import com.dengtacj.newssample.client.dto.clientobject.StockHistorySelectCO;
import com.dengtacj.newssample.common.MultiResponse;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

public interface HotspotEventServiceI {
    /**
     * 获取股票的涨跌幅
     * @param req
     * @return
     */
    public MultiResponse<StockHistoryQuoteCO> listStockHistoryQuoteQry(StockHistoryQuoteListQry req);

    /**
     * 获取有数据的过滤选项
     * @param req
     * @return
     */
    public MultiResponse<StockHistorySelectCO> listStockHistorySelectQry(StockHistorySelectListQry req);
}
