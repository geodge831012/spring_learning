package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/16 0016.
 */

@Data
public class RecommendAnnCO {
    String newsId;
    String title;
    String className;
    String sTime;
}
