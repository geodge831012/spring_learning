package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class TagNewsStatCO {
    /**
     * 日、周、月
     */
    String title;


    List<TagNewsStatItemCO> itemList;


    /**
     * 标签总数
     */
    int totalTagNum;

    /**
     * 敏感词总数
     */
    int sensitiveWordNum;
}
