package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/10 0010.
 */

@Data
public class NewsStatDO {
    int importAmount;
    int duplicatedAmount;
    int tagAmount;
    int eventAmount;
    long updateTime;
}
