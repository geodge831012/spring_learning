package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Data
public class NewsInfoDO {
    String id;
    String title = "";
    String content = "";
    String summary = "";
    String attitude;
    String source = "";
    String publishTime;
    String createTime;
    String imageUrl;
}
