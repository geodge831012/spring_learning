/**
 * 财联社数据库
 */
package com.dengtacj.newssample.infrastructure.database.cls;