package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.config.NewsConfig;
import com.dengtacj.newssample.config.NewsWritingType;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.StockInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.mapper.NewsClassMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Slf4j
@Component
public class NewsClassRepository {

    @Autowired
    NewsClassMapper newsClassMapper;

    @Autowired
    NewsConfig newsConfig;


    /**
     *  map<文章分类ID，List<文章ID>>
     */
    @Cache(expire = 240, key = "news-class:", autoload = true, alarmTime=60, requestTimeout = 0)
    public Map<String, List<String>> getNewsClassMapCache() {
        Map<String, List<String>> newsClassMapCache = new HashMap<>();

        for(NewsWritingType newsWritingType : newsConfig.getNewsWritingTypeList()) {
            ProgressTimer progressTimer = new ProgressTimer();
            String newsClassId = newsWritingType.getCode();
            List<String> newsIdList = newsClassMapper.listNewsIdByClass(newsClassId);
            newsClassMapCache.put(newsClassId, newsIdList);
            log.info("newsClass:" + newsWritingType.getDesc() + "|size:" + newsIdList.size() + "|time:" + progressTimer.elapse());
        }

        return newsClassMapCache;

    }



    /**
     * key: 股票代码
     * value: 股票名称
     */
    @Cache(expire = 3600, key = "stock-map:", autoload = true, alarmTime=60, requestTimeout = 0)
    public Map<String, String> getStockMapCache() {
        Map<String, String> stockMapCache = new HashMap<>();
        try {
            ProgressTimer progressTimer = new ProgressTimer();
            List<StockInfoDO> stockInfoList = newsClassMapper.listAllStock();
            for(StockInfoDO stockInfoDO : stockInfoList) {
                stockMapCache.put(stockInfoDO.getCode(), stockInfoDO.getName());
            }
            log.info("newsTag: stockMapCache|size:" + stockMapCache.size() + "|time:" + progressTimer.elapse());
        } catch (Exception ex) {
            log.error("exception:", ex);
        }
        return stockMapCache;
    }



}
