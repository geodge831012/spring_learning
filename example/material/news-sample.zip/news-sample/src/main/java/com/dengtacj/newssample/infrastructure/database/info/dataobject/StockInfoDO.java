package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class StockInfoDO {
    String code;
    String name;
}
