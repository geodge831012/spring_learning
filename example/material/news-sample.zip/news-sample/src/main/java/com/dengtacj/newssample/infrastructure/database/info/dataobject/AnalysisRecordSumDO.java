package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

import java.util.Date;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

@Data
public class AnalysisRecordSumDO {

    /**
     * dsId
     */
    private String tbSourceId;

    /**
     * 時間段内成功計數
     */
    private Integer successCountSum;

    /**
     * 今日更新次数
     */
    private Integer duplicatedCountSum;

    /**
     * 時間段内錯誤計數
     */
    private Integer errorCount;

    /**
     * 今日最长执行时间
     */
    private Integer todayMaxExecuteTime;

    /**
     * 今日执行总次数
     */
    private Integer todayExecuteCount;

}
