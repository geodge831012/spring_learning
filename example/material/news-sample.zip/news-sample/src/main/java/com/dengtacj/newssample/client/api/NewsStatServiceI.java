package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.clientobject.AnalysisRecordStatCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsStatDataCO;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.SingleResponse;

/**
 * Created by Administrator on 2019/9/23 0023.
 */

public interface NewsStatServiceI {

    /**
     * 获取统计数据
     * @return
     */
    public SingleResponse<NewsStatDataCO> newsStatDataQry();

    /**
     * 获取采集统计数据
     * @return
     */
    public MultiResponse<AnalysisRecordStatCO> listAnalysisRecordStatQry();

}
