package com.dengtacj.newssample.client.dto;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

public class NewsWritingTypeListQry {
}
