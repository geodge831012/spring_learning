package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Data
public class DetectEventListCO {
    List<DetectEventCO> detectEventList;
}
