package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class TagInfoCO {
    String code;
    String name;

    public TagInfoCO() {
    }

    public TagInfoCO(String name) {
        this.name = name;
    }

    public TagInfoCO(String code, String name) {
        this.name = name;
        this.code = code;
    }
}
