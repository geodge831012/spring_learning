package com.dengtacj.newssample.client.dto.clientobject;

import com.dengtacj.newssample.common.utils.CustomerDoubleSerialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class TagNewsStatItemCO {

    /**
     * 标签种类
     */
    String type;

    /**
     * 标签数量
     */
    int num;

    /**
     * 标签占比
     */
    @JsonSerialize(using = CustomerDoubleSerialize.class)
    double percent;


    public TagNewsStatItemCO() {}

    public TagNewsStatItemCO(String type, int num, double percent) {
        this.type = type;
        this.num = num;
        this.percent = percent;
    }
}
