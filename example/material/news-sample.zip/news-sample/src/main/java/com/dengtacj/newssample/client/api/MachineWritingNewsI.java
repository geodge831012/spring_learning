package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.NewsWritingListQry;
import com.dengtacj.newssample.client.dto.NewsWritingTypeListQry;
import com.dengtacj.newssample.client.dto.clientobject.NewsWritingCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsWritingTypeCO;
import com.dengtacj.newssample.common.MultiResponse;

/**
 * Created by Administrator on 2019/9/23 0023.
 */

public interface MachineWritingNewsI {

    /**
     * 获取机器写稿新闻列表
     * @return
     */
    public MultiResponse<NewsWritingCO> listNewsWritingQry(NewsWritingListQry req);

    /**
     * 获取机器写稿新闻类型列表
     * @return
     */
    public MultiResponse<NewsWritingTypeCO> listNewsWritingTypeQry(NewsWritingTypeListQry req);

}
