package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/18 0018.
 */

@Data
public class StockHistorySelectCO {
    /**
     * 事前3天 -3
     * 当日    0
     * 事后3天 3
     * 事后5天 5
     */
    int queryType;

    /**
     * 是否可用
     */
    boolean isAvailable;
}
