package com.dengtacj.newssample.client.dto;

import com.dengtacj.newssample.client.dto.clientobject.StockHistoryQryItem;
import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/17 0017.
 */

@Data
public class StockHistoryQuoteListQry {
    /**
     * 股票代码
     */
    List<StockHistoryQryItem> stockHisList;
    /**
     * 事前3天 -3
     * 当日    0
     * 事后3天 3
     * 事后5天 5
     */
    int queryType;
}
