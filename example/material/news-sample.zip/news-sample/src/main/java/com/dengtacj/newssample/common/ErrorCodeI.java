package com.dengtacj.newssample.common;

/**
 * Created by Administrator on 2019/9/3 0003.
 */

public interface ErrorCodeI {

    public String getErrCode();

    public String getErrDesc();
}
