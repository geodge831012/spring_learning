package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Data
public class NewsOfEventCO {
    String id;
    String title;
    String source;
    String publishTime;
    String createTime;
    List<TagInfoCO> tagList;
}
