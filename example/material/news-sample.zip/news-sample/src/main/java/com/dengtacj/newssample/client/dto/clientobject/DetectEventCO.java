package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Data
public class DetectEventCO {
    /**
     * 事件ID
     */
    String eventId;
    /**
     * 事件标题
     */
    String eventTitle;
    /**
     * 相关资讯数量
     */
    int newsNum;
    /**
     * 相关股票数量
     */
    int stockNum;
    /**
     * 热度值
     */
    int eventHot;
    /**
     * 创建时间
     */
    String createTime;
    /**
     * 标签列表
     */
    List<String> keywordList;
}
