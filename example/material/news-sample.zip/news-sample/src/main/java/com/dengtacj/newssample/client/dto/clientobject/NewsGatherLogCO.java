package com.dengtacj.newssample.client.dto.clientobject;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

public class NewsGatherLogCO {

}
