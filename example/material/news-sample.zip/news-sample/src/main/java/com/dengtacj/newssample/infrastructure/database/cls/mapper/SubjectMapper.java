package com.dengtacj.newssample.infrastructure.database.cls.mapper;

import com.dengtacj.newssample.infrastructure.database.cls.dataobject.LianSubjectDO;

import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

public interface SubjectMapper {
    /**
     *
     * @param createTime 大于该时间的所有记录，Unix时间戳（s）
     * @return
     */
    List<LianSubjectDO> list(Long createTime);
}
