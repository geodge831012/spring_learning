package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class EventDetectStatCO {
    /**
     * 3日、5日、7日
     */
    String title;


    List<EventDetectStatItemCO> itemList;

    /**
     * 标签总数
     */
    int eventNum;
}
