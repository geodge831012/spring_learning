package com.dengtacj.newssample.client.api;

import com.dengtacj.newssample.client.dto.*;
import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.SingleResponse;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

public interface NewsInfoServiceI {
    /**
     * 获取资讯详情
     * @return
     */
    public SingleResponse<NewsInfoCO> getNewsInfoQry(NewsInfoGetQry req);

    /**
     * 获取资讯标签
     * @return
     */
    public SingleResponse<NewsTagCO> getNewsTagQry(NewsTagGetQry req);

    /**
     * 获取资讯相关资讯
     * @return
     */
    public MultiResponse<RelatedNewsCO> listNewsRelatedQry(NewsRelatedListQry req);

    /**
     * 获取推荐资讯列表
     * @return
     */
    public MultiResponse<RecommendNewsCO> listRecommendNewsQry(RecommendNewListQry req);

    /**
     * 获取推荐公告列表
     * @return
     */
    public MultiResponse<RecommendAnnCO> listRecommendAnnQry(RecommendAnnListQry req);
}
