package com.dengtacj.newssample.infrastructure.database.real.mapper;

import com.dengtacj.newssample.infrastructure.database.real.dataobject.SecHisQuoteDO;
import com.jarvis.cache.annotation.Cache;
import com.jarvis.cache.annotation.CacheDelete;
import com.jarvis.cache.annotation.CacheDeleteKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Mapper
public interface DailyQuoteMapper {
    /**
     * 获取日行情数据
     * @param beginDate
     * @return
     */
    ArrayList<Long> listTradingDay(String beginDate);

    /**
     * 获取交易日数据
     * @param beginDate
     * @param endDate
     * @return
     */
    List<SecHisQuoteDO> listQuoteByTradingDay(@Param("beginDate") String beginDate, @Param("endDate")String endDate);

}
