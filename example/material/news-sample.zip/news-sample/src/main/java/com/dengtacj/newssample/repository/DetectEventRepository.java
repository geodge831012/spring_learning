package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.common.utils.SimilarEnum;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.DetectEventDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.EventInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.EventKeywordDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.StockWithScoreDO;
import com.dengtacj.newssample.infrastructure.database.info.mapper.DetectEventMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Slf4j
@Component
public class DetectEventRepository {

    @Autowired
    DetectEventMapper detectEventMapper;

    @Autowired
    NewsClassRepository newsClassRepository;

    @Value("${news.newsFlash.accessHistoryDay}")
    Long accessHistoryDay;


    /**
     * key: 事件id
     * value: 事件标题
     */
    @Cache(expire = 600, key = "event-map:", autoload = true, alarmTime=60, requestTimeout = 0)
    public Map<String, String> getEventMapCache() {
        Map<String, String> eventMapCache = new HashMap<>();

        ProgressTimer progressTimer = new ProgressTimer();
        List<EventInfoDO> eventInfoList = detectEventMapper.listAllEvent();
        for(EventInfoDO eventInfoDO : eventInfoList) {
            eventMapCache.put(eventInfoDO.getEventId(), eventInfoDO.getEventTitle());
        }
        log.info("newsTag: stockMapCache|size:" + eventMapCache.size() + "|time:" + progressTimer.elapse());

        return eventMapCache;
    }


    @Cache(expire = 600, key = "'event-list:'", autoload = true, alarmTime=60, requestTimeout = 0)
    public List<DetectEventCO> getDetectEventList() {
        ProgressTimer timer = new ProgressTimer();
        List<DetectEventCO> detectEventCOList = new LinkedList<>();

        // 从数据库中读取, 计算查询时间
        Long now = System.currentTimeMillis()/1000;
        Long beginTime = now - accessHistoryDay * 24 * 60 * 60;
        String beginTimeStr = DateUtil.date2str(new Date(beginTime*1000), "yyyy-MM-dd");

        List<DetectEventDO> detectEventDOList = detectEventMapper.listEventByDate(beginTimeStr);

        for(DetectEventDO detectEventDO : detectEventDOList) {
            DetectEventCO detectEventCO = new DetectEventCO();
            detectEventCO.setEventId(detectEventDO.getEventId());
            detectEventCO.setEventTitle(detectEventDO.getEventTitle());
            detectEventCO.setCreateTime(detectEventDO.getCreateTime());
            detectEventCO.setEventHot(detectEventDO.getEventHot());
            detectEventDO.setStockNum(detectEventDO.getStockNum());
            detectEventCO.setNewsNum(detectEventCO.getNewsNum());
            List<String> keyWordList = new LinkedList<>();
            if(detectEventDO.getKeywordList() != null) {
                keyWordList = Arrays.asList(detectEventDO.getKeywordList().split(","));
            }
            detectEventCO.setKeywordList(keyWordList);
            BeanUtils.copyProperties(detectEventDO, detectEventCO);
            detectEventCOList.add(detectEventCO);
        }

        log.info("from cache getDetectEventList|" + timer.elapse());
        return detectEventCOList;
    }

    @Cache(expire = 600, key = "'news-list-with-event:' + #args[0]")
    public List<String> listNewsWithDetectEvent(String eventId) {
        return detectEventMapper.listNewsIdByEventId(eventId);
    }

    @Cache(expire = 600, key = "'stock-list-with-event:' + #args[0]")
    public List<StockOfEventCO> listStockWithDetectEventQry(String eventId) {
        List<StockOfEventCO> stockOfEventList = new LinkedList<>();
        List<StockWithScoreDO> stockDOList = detectEventMapper.listStockCodeByEventId(eventId);

        Map<String, String> stockMap = newsClassRepository.getStockMapCache();
        for(StockWithScoreDO stockDO : stockDOList) {
            StockOfEventCO stock = new StockOfEventCO();
            String stockName = stockMap.get(stockDO.getStockCode());
            stock.setCode(stockDO.getStockCode());
            stock.setName(stockName);
            stock.setCount(stockDO.getCount());
            stockOfEventList.add(stock);
        }
        similar(stockOfEventList, eventId);
        return stockOfEventList;
    }

    //计算相似度
    public List<StockOfEventCO> similar(List<StockOfEventCO> listStock, String eventId) {

        //事件的核心标签
        List<EventKeywordDO> listKeys = detectEventMapper.listKeywordByEventId(eventId);

        for(StockOfEventCO stock : listStock){
            for(EventKeywordDO key : listKeys){
                if(key.getKeyword().equals(stock.getName())){
                    Integer type = SimilarEnum.getMessageSc(key.getType());
                    Integer num = type*stock.getCount();
                    stock.setCount(num);
                    break;
                }
            }
        }

        //按照相似度降序排列，计算加权平均值需要
        Collections.sort(listStock, new Comparator<StockOfEventCO>() {
            @Override
            public int compare(StockOfEventCO o1, StockOfEventCO o2) {
                //降序
                return o2.getCount().compareTo(o1.getCount());
            }
        });

        if(!CollectionUtils.isEmpty(listStock)){
            int max = listStock.get(0).getCount();
            int min = listStock.get(listStock.size()-1).getCount();
            log.info("事件id为: "+ eventId +" 的最大加权平均数是："+max);
            log.info("事件id为: "+ eventId +" 的最小加权平均数是："+min);

            //计算相似度
            for(StockOfEventCO stock : listStock){
                int similar = CommonUtil.calSemilar(stock.getCount(),max,min);

                stock.setSimilar(similar);


                // 将5分制转换为100分制
                int beta = 0;
                if(CommonUtil.isNumeric(stock.getCode())) {
                    beta = Integer.parseInt(stock.getCode());
                }
                stock.setSimilar(CommonUtil.convertScore(similar, beta));
            }
        }

        //按照相似度降序排列
        Collections.sort(listStock, new Comparator<StockOfEventCO>() {
            @Override
            public int compare(StockOfEventCO o1, StockOfEventCO o2) {
                //降序
                return o2.getSimilar().compareTo(o1.getSimilar());
            }
        });

        return listStock;
    }

}
