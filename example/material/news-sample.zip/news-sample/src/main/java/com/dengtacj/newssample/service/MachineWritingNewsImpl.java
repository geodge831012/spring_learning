package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.MachineWritingNewsI;
import com.dengtacj.newssample.client.dto.NewsWritingListQry;
import com.dengtacj.newssample.client.dto.NewsWritingTypeListQry;
import com.dengtacj.newssample.client.dto.clientobject.NewsInfoCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsWritingCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsWritingTypeCO;
import com.dengtacj.newssample.common.ErrorCode;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.PageUtil;
import com.dengtacj.newssample.config.NewsConfig;
import com.dengtacj.newssample.config.NewsWritingType;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsInfoDO;
import com.dengtacj.newssample.repository.NewsClassRepository;
import com.dengtacj.newssample.repository.NewsInfoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/9/29 0029.
 */

@Service
@Slf4j
public class MachineWritingNewsImpl implements MachineWritingNewsI {
    @Autowired
    NewsClassRepository newsClassRepository;

    @Autowired
    NewsInfoRepository newsInfoRepository;

    @Autowired
    NewsConfig newsConfig;

    @Value("${news.common.pageSize}")
    int pageSize;

    @Override
    public MultiResponse<NewsWritingCO> listNewsWritingQry(NewsWritingListQry req) {
        try {
            List<String> newsIdList;
            if(!req.getNewsType().isEmpty()) {
                newsIdList = newsClassRepository.getNewsClassMapCache().getOrDefault(req.getNewsType(), new LinkedList<>());
            } else {
                newsIdList = newsInfoRepository.getMachineWritingNewsIdListCache();
            }

            // 分页
            PageUtil<String> pageUtil = new PageUtil<>();
            List<String> pagedNewsIdList = pageUtil.getCurrentPageByApp(String.class.getName(), "toString",
                    newsIdList, req.getDirection(), req.getStartId(), pageSize);

            Map<String, NewsInfoCO> newsInfoCOMap = newsInfoRepository.batchGetByNewsId(pagedNewsIdList);
            List<NewsWritingCO> newsWritingCOList = new LinkedList<>();
            for(String newsId : pagedNewsIdList) {
                NewsInfoCO newsInfoCO = newsInfoCOMap.get(newsId);
                NewsWritingCO newsWritingCO = new NewsWritingCO();
                newsWritingCO.setId(newsInfoCO.getId());
                newsWritingCO.setTitle(newsInfoCO.getTitle());
                newsWritingCO.setCreateTime(newsInfoCO.getCreateTime());
                newsWritingCO.setPublishTime(newsInfoCO.getPublishTime());
                newsWritingCO.setSummary(newsInfoCO.getSummary());
                newsWritingCO.setImageUrl(newsInfoCO.getImageUrl());
                newsWritingCOList.add(newsWritingCO);
            }
            return MultiResponse.of(newsWritingCOList, pageUtil.isHaveMore(), pageUtil.getiTotal());
        } catch (Throwable ex) {
            log.error("ex:", ex);
            return MultiResponse.buildFailure(ErrorCode.E_Node_unknownError);
        }
    }

    public MultiResponse<NewsWritingTypeCO> listNewsWritingTypeQry(NewsWritingTypeListQry req) {
        try {
            List<NewsWritingTypeCO> newsWritingCOList = new LinkedList<>();
            for(NewsWritingType newsWritingType : newsConfig.getNewsWritingTypeList()) {
                NewsWritingTypeCO newsTypeCO = new NewsWritingTypeCO();
                newsTypeCO.setId(newsWritingType.getCode());
                newsTypeCO.setTypeName(newsWritingType.getDesc());
                newsWritingCOList.add(newsTypeCO);
            }
            return MultiResponse.ofWithoutTotal(newsWritingCOList);
        } catch (Throwable ex) {
            log.error("ex:", ex);
            return MultiResponse.buildFailure(ErrorCode.E_Node_unknownError);
        }
    }
}
