package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class TodayNewsStatCO {

    List<TodayNewsStatItemCO> itemList;

    Long updateTime;
}
