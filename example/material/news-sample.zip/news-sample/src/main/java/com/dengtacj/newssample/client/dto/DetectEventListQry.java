package com.dengtacj.newssample.client.dto;

import com.dengtacj.newssample.common.AppPageQuery;

/**
 * Created by Administrator on 2019/10/15 0015.
 */

public class DetectEventListQry  extends AppPageQuery {
}
