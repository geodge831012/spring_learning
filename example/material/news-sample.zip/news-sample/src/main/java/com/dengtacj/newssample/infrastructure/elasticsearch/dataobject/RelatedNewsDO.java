package com.dengtacj.newssample.infrastructure.elasticsearch.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/11 0011.
 */

@Data
public class RelatedNewsDO {
    String newsId;

    String title;
}
