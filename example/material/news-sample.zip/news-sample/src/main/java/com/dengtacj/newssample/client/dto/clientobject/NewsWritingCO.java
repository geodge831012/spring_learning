package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;


/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class NewsWritingCO {
    /**
     * 新闻ID
     */
    String id;
    /**
     * 标题
     */
    String title;
    /**
     * 摘要
     */
    String summary;

    /**
     * 创建时间
     */
    String createTime;

    /**
     * 发布时间
     */
    String publishTime;

    /**
     * 配图
     */
    String imageUrl;

}
