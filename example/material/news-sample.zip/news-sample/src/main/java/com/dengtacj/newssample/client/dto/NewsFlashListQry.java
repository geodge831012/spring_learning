package com.dengtacj.newssample.client.dto;

import com.dengtacj.newssample.common.AppPageQuery;

/**
 * Created by Administrator on 2019/9/23 0023.
 */

public class NewsFlashListQry extends AppPageQuery {
    /**
     * 文章分类
     */
    String category;

}
