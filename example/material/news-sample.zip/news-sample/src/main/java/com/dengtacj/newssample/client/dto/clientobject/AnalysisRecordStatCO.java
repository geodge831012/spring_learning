package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.Date;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class AnalysisRecordStatCO {
    /**
     * 数据源名称
     */
    private String sourceName;

    /**
     * 数据更新时间
     */
    private String updateTime;


    /**
     * 最近一次狀態 分析状态 0-正常 1-异常 2-进行中
     */
    private Integer analysisStatus;

    /**
     * 最近一次執行時刻
     */
    private String lastTime;

    /**
     * dsId
     */
    private String tbSourceId;

    /**
     * 最近一次成功計數
     */
    private Integer successCount;

    /**
     * 時間段内成功計數
     */
    private Integer successCountSum;

    /**
     * 時間段内錯誤計數
     */
    private Integer errorCount;
    /**
     * 启用状态 0-启用 1-禁用
     */
    private Integer enabled;


    /**
     * 上次执行时间
     */
    private Long lastExecuteTime;

    /**
     * 今日最长执行时间
     */
    private Integer todayMaxExecuteTime;

    /**
     * 今日执行总次数
     */
    private Integer todayExecuteCount;


    /**
     * 当前时间
     */
    private String currentTime;


    /**
     * 当前更新次数
     */
    private Integer duplicatedCount;

    /**
     * 今日更新次数
     */
    private Integer duplicatedCountSum;
}
