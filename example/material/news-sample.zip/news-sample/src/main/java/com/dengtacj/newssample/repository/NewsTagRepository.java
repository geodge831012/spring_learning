package com.dengtacj.newssample.repository;

import com.alibaba.fastjson.JSON;
import com.dengtacj.newssample.client.dto.clientobject.NewsTagCO;
import com.dengtacj.newssample.client.dto.clientobject.TagInfoCO;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.*;
import com.dengtacj.newssample.infrastructure.database.info.mapper.NewsTagMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Slf4j
@Component
public class NewsTagRepository {

    @Value("${news.newsTag.maxTagNum}")
    int maxTagNum;

    @Value("${news.newsTag.maxStockTagNum}")
    int maxStockTagNum;

    @Autowired
    NewsTagMapper newsTagMapper;

    @Autowired
    DetectEventRepository detectEventRepository;

    @Autowired
    NewsClassRepository newsClassRepository;

    /**
     * 首先从Redis中获取，若没有从数据库中读取并更新缓存
     * 若不存在返回null
     * @param newsId
     * @return
     */
    @Cache(expire = 3600, expireExpression = "null == #retVal ? 60: 3600", key = "'news-tag:' + #args[0]")
    public NewsTagCO getNewsTag(String newsId) {
        ProgressTimer timer = new ProgressTimer();
        NewsTagCO newsTagCO = null;

        // 从数据库中读取
        NewsTagDO newsTagDO = newsTagMapper.getNewsTags(newsId);
        if (newsTagDO == null) {
            log.info("from db getNewsTag:" + newsId + "|" + timer.elapse());
            return newsTagCO;
        }
        newsTagCO = convertToNewTagCO(newsTagDO);

        return newsTagCO;
    }

    NewsTagCO convertToNewTagCO(NewsTagDO newsTagDO) {
        NewsTagCO newsTagCO = new NewsTagCO();
        newsTagCO.setRelatedPeople(parseNewsTag(newsTagDO.getRelatedPeople()));
        newsTagCO.setRelatedOrgans(parseNewsTag(newsTagDO.getRelatedOrgans()));
        newsTagCO.setRelatedDistricts(parseNewsTag(newsTagDO.getRelatedDistricts()));
        newsTagCO.setRelatedPlateConcept(parseNewsTag(newsTagDO.getRelatedPlateConcept()));
        newsTagCO.setRelatedPlateDistricts(parseNewsTag(newsTagDO.getRelatedPlateDistricts()));
        newsTagCO.setRelatedPlateIndustry(parseNewsTag(newsTagDO.getRelatedPlateIndustry()));
        newsTagCO.setRelatedChain(parseNewsTag(newsTagDO.getRelatedChain()));
        List<TagInfoCO> mainKeywordList = parseNewsTag(newsTagDO.getMainKeyword());
        mainKeywordList.addAll(parseNewsTag(newsTagDO.getViceKeyword()));
        newsTagCO.setRelatedKeyword(mainKeywordList);


        // 相关股票，股票代码用逗号分割
        Map<String, String> stockMapCache = newsClassRepository.getStockMapCache();
        List<TagInfoCO> secTagList = new LinkedList<>();
        if(newsTagDO.getRelatedSecCode() != null && !newsTagDO.getRelatedSecCode().isEmpty()) {
            String[] strArray = newsTagDO.getRelatedSecCode().split(",");
            for(String code : strArray) {
                if(secTagList.size() >= maxStockTagNum) {
                    break;
                }
                String stockName = stockMapCache.get(code);
                if(stockName != null) {
                    TagInfoCO tagInfoCO = new TagInfoCO(code, stockName);
                    secTagList.add(tagInfoCO);
                }
            }
        }
        newsTagCO.setRelatedSec(secTagList);


        // 相关事件，事件ID用逗号分割
        Map<String, String> eventMapCache = detectEventRepository.getEventMapCache();
        List<TagInfoCO> eventTagList = new LinkedList<>();
        if(newsTagDO.getRelatedEventId() != null && !newsTagDO.getRelatedEventId().isEmpty()) {
            String[] strArray = newsTagDO.getRelatedEventId().split(",");
            for(String code : strArray) {
                if(eventTagList.size() >= maxTagNum) {
                    break;
                }
                String stockName = eventMapCache.get(code);
                if(stockName != null) {
                    TagInfoCO tagInfoCO = new TagInfoCO(code, stockName);
                    eventTagList.add(tagInfoCO);
                }
            }
        }
        newsTagCO.setRelatedEvent(eventTagList);

        return newsTagCO;
    }

    List<TagInfoCO> parseNewsTag(String jsonStr) {
        if(jsonStr == null || jsonStr.isEmpty()) {
            return new LinkedList<>();
        }
        List<String> strList = JSON.parseArray(jsonStr, String.class);
        if(strList == null) {
            return new LinkedList<>();
        }

        List<TagInfoCO> tagInfoList = new LinkedList<>();
        for(String str : strList) {
            if(tagInfoList.size() >= maxTagNum) {
                break;
            }
            TagInfoCO tagInfoCO = new TagInfoCO();
            tagInfoCO.setName(str);
            tagInfoList.add(tagInfoCO);
        }
        return tagInfoList;
    }

}
