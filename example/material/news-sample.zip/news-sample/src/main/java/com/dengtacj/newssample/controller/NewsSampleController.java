package com.dengtacj.newssample.controller;

import com.dengtacj.newssample.client.api.*;
import com.dengtacj.newssample.client.dto.*;
import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.SingleResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Administrator on 2019/9/24 0024.
 */
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class NewsSampleController {

    @Autowired
    NewsFlashServiceI newsFlashService;

    @Autowired
    MachineWritingNewsI machineWritingNews;

    @Autowired
    NewsInfoServiceI newsInfoService;

    @Autowired
    NewsStatServiceI newsStatService;

    @Autowired
    DetectEventServiceI detectEventService;

    @Autowired
    HotspotEventServiceI hotspotEventService;


    @PostMapping(value = "/news/v1/list_news_flash")
    public MultiResponse<NewsFlashCO> listNewsFlash(@RequestBody NewsFlashListQry req){
        return newsFlashService.listNewsFlash(req);
    }

    @PostMapping(value = "/news/v1/list_writing_news")
        public MultiResponse<NewsWritingCO> listWritingNews(@RequestBody NewsWritingListQry req){
        return machineWritingNews.listNewsWritingQry(req);
    }


    @PostMapping(value = "/news/v1/list_writing_news_type")
    public MultiResponse<NewsWritingTypeCO> listWritingNewsType(){
        NewsWritingTypeListQry req = new NewsWritingTypeListQry();
        return machineWritingNews.listNewsWritingTypeQry(req);
    }

    @PostMapping(value = "/news/v1/get_news_info")
    public SingleResponse<NewsInfoCO> getNewsInfo(@RequestBody NewsInfoGetQry req){
        return newsInfoService.getNewsInfoQry(req);
    }

    @PostMapping(value = "/news/v1/get_news_tag")
    public SingleResponse<NewsTagCO> getNewsTag(@RequestBody NewsTagGetQry req){
        return newsInfoService.getNewsTagQry(req);
    }

    @PostMapping(value = "/news/v1/list_news_related")
    public MultiResponse<RelatedNewsCO> listNewsRelated(@RequestBody NewsRelatedListQry req){
        return newsInfoService.listNewsRelatedQry(req);
    }

    @PostMapping(value = "/news/v1/get_news_stat")
    public SingleResponse<NewsStatDataCO> getNewsStat(){
        return newsStatService.newsStatDataQry();
    }

    @PostMapping(value = "/news/v1/list_analysis_record_stat")
    public MultiResponse<AnalysisRecordStatCO> listAnalysisRecordStat(){
        return newsStatService.listAnalysisRecordStatQry();
    }

    @PostMapping(value = "/news/v1/list_detect_event")
    public MultiResponse<DetectEventCO> listDetectEvent(@RequestBody DetectEventListQry req){
        return detectEventService.listDetectEventQry(req);
    }

    @PostMapping(value = "/news/v1/list_news_of_detect_event")
    public MultiResponse<NewsOfEventCO> listNewsWithDetectEvent(@RequestBody NewsWithDetectEventListQry req){
        return detectEventService.listNewsOfDetectEventQry(req);
    }

    @PostMapping(value = "/news/v1/list_stock_of_detect_event")
    public MultiResponse<StockOfEventCO> listStockOfDetectEvent(@RequestBody StockWithDetectEventListQry req){
        return detectEventService.listStockOfDetectEventQry(req);
    }

    @PostMapping(value = "/news/v1/list_recommend_news")
    public MultiResponse<RecommendNewsCO> listRecommendNews(){
        return newsInfoService.listRecommendNewsQry(new RecommendNewListQry());
    }

    @PostMapping(value = "/news/v1/list_recommend_ann")
    public MultiResponse<RecommendAnnCO> listRecommendAnn(){
        return newsInfoService.listRecommendAnnQry(new RecommendAnnListQry());
    }

    @PostMapping(value = "/news/v1/list_stock_history_quote")
    public MultiResponse<StockHistoryQuoteCO> listStockHistoryQuote(@RequestBody StockHistoryQuoteListQry req){
        return hotspotEventService.listStockHistoryQuoteQry(req);
    }

    @PostMapping(value = "/news/v1/list_stock_history_select")
    public MultiResponse<StockHistorySelectCO> listStockHistorySelect(@RequestBody StockHistorySelectListQry req){
        return hotspotEventService.listStockHistorySelectQry(req);
    }
}
