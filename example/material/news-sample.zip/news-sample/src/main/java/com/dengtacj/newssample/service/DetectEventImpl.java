package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.DetectEventServiceI;
import com.dengtacj.newssample.client.dto.DetectEventListQry;
import com.dengtacj.newssample.client.dto.NewsWithDetectEventListQry;
import com.dengtacj.newssample.client.dto.StockWithDetectEventListQry;
import com.dengtacj.newssample.client.dto.clientobject.*;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.utils.PageUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.repository.DetectEventRepository;
import com.dengtacj.newssample.repository.NewsInfoRepository;
import com.dengtacj.newssample.repository.NewsTagRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2019/10/14 0014.
 */

@Slf4j
@Service
public class DetectEventImpl implements DetectEventServiceI {

    @Autowired
    DetectEventRepository eventRepository;

    @Autowired
    NewsInfoRepository newsInfoRepository;

    @Autowired
    NewsTagRepository newsTagRepository;


    @Value("${news.common.pageSize}")
    int pageSize;

    @Value("${news.detectEvent.stockPageSize}")
    int stockPageSize;

    /**
     * 获取事件列表
     * @return
     */
    @Override
    public MultiResponse<DetectEventCO> listDetectEventQry(DetectEventListQry req) {
        List<DetectEventCO> detectEventList = eventRepository.getDetectEventList();

        // 分页
        PageUtil<DetectEventCO> pageUtil = new PageUtil<>();
        List<DetectEventCO> pagedEventList = pageUtil.getCurrentPageByApp(DetectEventCO.class.getName(), "getEventId",
                detectEventList, req.getDirection(), req.getStartId(), pageSize);

        return MultiResponse.of(pagedEventList, pageUtil.isHaveMore(), pageUtil.getiTotal());
    }

    /**
     * 获取事件相关的资讯列表
     * @return
     */
    @Override
    public MultiResponse<NewsOfEventCO> listNewsOfDetectEventQry(NewsWithDetectEventListQry req) {
        List<NewsOfEventCO> newsOfEventList = new LinkedList<>();

        ProgressTimer timer = new ProgressTimer();
        List<String> newsIdList = eventRepository.listNewsWithDetectEvent(req.getEventId());
        log.info("listNewsOfDetectEventQry 1:" + timer.elapse());

        // 分页
        PageUtil<String> pageUtil = new PageUtil<>();
        List<String> pagedNewsIdList = pageUtil.getCurrentPageByApp(String.class.getName(), "toString",
                newsIdList, req.getDirection(), req.getStartId(), pageSize);

        timer = new ProgressTimer();
        Map<String, NewsInfoCO> newsInfoCOMap = newsInfoRepository.batchGetByNewsId(pagedNewsIdList);

        log.info("listNewsOfDetectEventQry 2:" + timer.elapse());

        for(String newsId : pagedNewsIdList) {
            NewsOfEventCO newsWithEvent = new NewsOfEventCO();
            // 填写资讯信息
            NewsInfoCO newsInfoCO = newsInfoCOMap.get(newsId);
            if(newsInfoCO != null) {
                newsWithEvent.setId(newsInfoCO.getId());
                newsWithEvent.setTitle(newsInfoCO.getTitle());
                newsWithEvent.setCreateTime(newsInfoCO.getCreateTime());
                newsWithEvent.setPublishTime(newsInfoCO.getPublishTime());
                newsWithEvent.setSource(newsInfoCO.getSource());
            }

            // 填写标签信息
            log.info("listNewsOfDetectEventQry 2:" + timer.elapse());
            timer = new ProgressTimer();
            newsWithEvent.setTagList(new LinkedList<>());
            NewsTagCO newsTagCO = newsTagRepository.getNewsTag(newsId);
            if(newsTagCO != null) {
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedSec());
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedPlateIndustry());
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedPlateConcept());
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedPlateDistricts());
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedPeople());
                newsWithEvent.getTagList().addAll(newsTagCO.getRelatedChain());
            }
            newsOfEventList.add(newsWithEvent);
            log.info("listNewsOfDetectEventQry 2:" + timer.elapse());
        }

        return MultiResponse.of(newsOfEventList, pageUtil.isHaveMore(), pageUtil.getiTotal());
    }

    /**
     * 获取事件相关的股票列表
     * @return
     */
    @Override
    public MultiResponse<StockOfEventCO> listStockOfDetectEventQry(StockWithDetectEventListQry req) {
        List<StockOfEventCO> stockList = eventRepository.listStockWithDetectEventQry(req.getEventId());

        // 分页
        PageUtil<StockOfEventCO> pageUtil = new PageUtil<>();
        List<StockOfEventCO> pagedStockList = pageUtil.getCurrentPageByApp(StockOfEventCO.class.getName(), "getCode",
                stockList, req.getDirection(), req.getStartId(), stockPageSize);
        return MultiResponse.of(pagedStockList, pageUtil.isHaveMore(), pageUtil.getiTotal());
    }
}
