package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.client.dto.clientobject.AnalysisRecordStatCO;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.common.utils.ProgressTimer;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.AnalysisRecordCountDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.AnalysisRecordSumDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.SourceConfigDO;
import com.dengtacj.newssample.infrastructure.database.info.mapper.AnalysisRecordMapper;
import com.jarvis.cache.annotation.Cache;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.javassist.bytecode.stackmap.BasicBlock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.text.ParseException;
import java.util.*;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

@Slf4j
@Component
public class AnalysisRecordRepository {

    String[] sourceNameList = { "财联社", "证券日报", "上海证券报", "中国证券报", "证券时报", "爬虫"};

    Set<String> sourceNameSet = new HashSet<>(Arrays.asList(sourceNameList));

    @Autowired
    AnalysisRecordMapper analysisRecordMapper;

    @Cache(expire = 240, key = "record-stat:", autoload = true, alarmTime=60, requestTimeout = 0)
    public List<AnalysisRecordStatCO> getAnalysisRecordStatListCache() throws ParseException{
        List<AnalysisRecordStatCO> analysisRecordStatListCache = new LinkedList<>();
        ProgressTimer timer = new ProgressTimer();
        // 获取已经配置数据源列表
        List<AnalysisRecordStatCO> analysisRecordStatList = new ArrayList<>();
        List<SourceConfigDO> allDbSource = analysisRecordMapper.listSourceConfig();
        allDbSource.removeIf(entity -> !sourceNameSet.contains(entity.getSourceName()));
        if (CollectionUtils.isEmpty(allDbSource)) {
            return analysisRecordStatListCache;
        }

        // 获取数据源的最新的同步记录
        List<AnalysisRecordCountDO> latestRecordList = new LinkedList<>();
        allDbSource.forEach(entity -> {
            AnalysisRecordCountDO recordCountDO = analysisRecordMapper.getLatestRecord(entity.getId());
            if(recordCountDO != null) {
                latestRecordList.add(recordCountDO);
            }
        });
        Map<String, AnalysisRecordCountDO> latestRecordMap = new HashMap<>();
        latestRecordList.forEach( entity -> latestRecordMap.put(entity.getTbSourceId(), entity) );


        // 获取数据源的当天的统计记录
        String beginTime = DateUtil.date2str(new Date(), "yyyy-MM-dd");
        List<AnalysisRecordSumDO> todayRecordList = analysisRecordMapper.listRecordSum(beginTime);
        Map<String, AnalysisRecordSumDO> todayRecordMap = new HashMap<>();
        todayRecordList.forEach( entity -> todayRecordMap.put(entity.getTbSourceId(), entity) );

        // 组合数据结果
        for(SourceConfigDO sourceConfig : allDbSource) {
            analysisRecordStatList.add(fillRecordStat(sourceConfig, latestRecordMap, todayRecordMap));
        }
        analysisRecordStatListCache = analysisRecordStatList;
        log.info("stat:freshRecordStatList|size:" + analysisRecordStatListCache.size() + "|time:" + timer.elapse());

        return analysisRecordStatListCache;

    }


    private AnalysisRecordStatCO fillRecordStat(SourceConfigDO dsEntity, Map<String, AnalysisRecordCountDO> latestMap,
                                                     Map<String, AnalysisRecordSumDO> todayMap) throws ParseException{
        String now = DateUtil.date2str(new Date(), null);

        AnalysisRecordStatCO co = new AnalysisRecordStatCO();
        co.setSourceName(dsEntity.getSourceName());
        co.setTbSourceId(dsEntity.getId());
        co.setEnabled(dsEntity.getEnabled());
        co.setCurrentTime(now);
        AnalysisRecordCountDO latest = latestMap.get(dsEntity.getId());
        AnalysisRecordSumDO today = todayMap.get(dsEntity.getId());

        if (null != latest) {
            co.setAnalysisStatus(latest.getAnalysisStatus());
            co.setSuccessCount(latest.getSuccessCount());
            String updateTimeStr = latest.getUpdateTime() == null ? now : latest.getUpdateTime();
            co.setUpdateTime(updateTimeStr);
            co.setLastTime(latest.getLastTime());
            co.setDuplicatedCount(latest.getDuplicatedCount());

            Date updateTime = DateUtil.str2date(updateTimeStr, null);
            Date lastTime = DateUtil.str2date(co.getLastTime(), null);
            co.setLastExecuteTime((updateTime.getTime()-lastTime.getTime()) / 1000);
        }

        if (today != null) {
            co.setSuccessCountSum(today.getSuccessCountSum());
            co.setTodayMaxExecuteTime(today.getTodayMaxExecuteTime());
            co.setDuplicatedCountSum(today.getDuplicatedCountSum());
            co.setErrorCount(today.getErrorCount());
            co.setTodayExecuteCount(today.getTodayExecuteCount());
        }
        return co;
    }
}