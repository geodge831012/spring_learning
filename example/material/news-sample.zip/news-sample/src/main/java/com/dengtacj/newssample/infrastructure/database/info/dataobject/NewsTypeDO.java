package com.dengtacj.newssample.infrastructure.database.info.dataobject;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

public enum NewsTypeDO {
    E_original (0, "原创新闻"),
    E_not_original(1, "非原创新闻"),
    E_machine_writing(2, "机器写稿新闻");

    private final int code;
    private final String desc;

    private NewsTypeDO(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
