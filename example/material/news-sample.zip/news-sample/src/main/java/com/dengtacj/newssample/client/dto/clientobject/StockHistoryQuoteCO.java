package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/17 0017.
 */

@Data
public class StockHistoryQuoteCO implements Comparable<StockHistoryQuoteCO>{
    /**
     * 股票代码
     */
    String dtSecCode;

    /**
     * 日期
     */
    String dateStr;

    /**
     * 涨跌幅
     */
    String rate;

    public int compareTo(StockHistoryQuoteCO o) {
        if(Float.parseFloat(rate) > Float.parseFloat(o.getRate())) {
            return 1;
        } else {
            return -1;
        }
    }
}
