package com.dengtacj.newssample.client.dto;

import com.dengtacj.newssample.common.AppPageQuery;
import lombok.Data;

/**
 * Created by Administrator on 2019/9/27 0027.
 */

@Data
public class NewsWritingListQry extends AppPageQuery  {
    String newsType = "";
}
