package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;


@Data
public class NewsFlashCO{
    public static final int IMPORTANCE_LEVEL_GENERAL  = 0;
    public static final int IMPORTANCE_LEVEL_MEDIUM  = 1;
    public static final int IMPORTANCE_LEVEL_HIGH  = 2;


    /**
     * 文章Id
     */
    private String articleId;

    /**
     * 发布时间
     */
    private long publishTime;

    /**
     * 内容
     */
    private String content;

    /**
     * 重要等级 0:普通，1:重要，2:非常重要
     */
    private int ImportanceLevel;

    /**
     * 相关话题
     */
    private List<String> subjectList;
}
