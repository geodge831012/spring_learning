package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/16 0016.
 */

@Data
public class RecommendAnnDO {
    String sTime;
    String sId;
    String eDataDbSource;
    String eNewsTable;
    String title;
    String className;
}
