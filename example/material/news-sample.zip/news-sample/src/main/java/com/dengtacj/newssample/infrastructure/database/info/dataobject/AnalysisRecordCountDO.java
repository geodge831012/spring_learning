package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

import java.util.Date;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

@Data
public class AnalysisRecordCountDO {

    /**
     * 最近一次執行時刻
     */
    private String lastTime;

    /**
     * 数据更新时间
     */
    private String updateTime;

    /**
     * dsId
     */
    private String tbSourceId;

    /**
     * 最近一次狀態 分析状态 0-正常 1-异常 2-进行中
     */
    private Integer analysisStatus;

    /**
     * 最近一次成功計數
     */
    private Integer successCount;

    /**
     * 当前更新次数
     */
    private Integer duplicatedCount;
}
