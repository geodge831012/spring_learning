package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/10 0010.
 */

@Data
public class EventDetectStatDO {

    String sourceName;

    int threeDayAmount;

    int fiveDayAmount;

    int sevenDayAmount;
}
