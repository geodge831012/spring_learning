package com.dengtacj.newssample.infrastructure;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.mapper.NewsInfoMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@RunWith(SpringRunner.class)
@SpringBootTest
public class infoTest {
    @Autowired
    NewsInfoMapper newsInfoMapper;

}
