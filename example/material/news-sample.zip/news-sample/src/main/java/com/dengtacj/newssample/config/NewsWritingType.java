package com.dengtacj.newssample.config;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

public class NewsWritingType {
    private final String code;
    private final String desc;

    public NewsWritingType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public String getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
