package com.dengtacj.newssample.client.dto.clientobject;

import com.dengtacj.newssample.common.utils.CustomerDoubleSerialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;

/**
 * Created by Administrator on 2019/9/26 0026.
 */

@Data
public class TodayNewsStatItemCO {
    /**
     * 显示名称
     */
    String name;
    /**
     * 占比
     */
    @JsonSerialize(using = CustomerDoubleSerialize.class)
    Double percent = 0.00;
    /**
     * 当前值
     */
    int currNum = 0;
}
