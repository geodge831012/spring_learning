package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class NewsInfoCO {
    String id;
    String title;
    String content;
    String summary;
    String attitude;
    String source;
    String publishTime;
    String createTime;
    String imageUrl;
}
