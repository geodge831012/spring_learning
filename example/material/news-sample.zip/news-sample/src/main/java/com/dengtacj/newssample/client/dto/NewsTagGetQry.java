package com.dengtacj.newssample.client.dto;

import lombok.Data;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

@Data
public class NewsTagGetQry {
    String newsId;
}
