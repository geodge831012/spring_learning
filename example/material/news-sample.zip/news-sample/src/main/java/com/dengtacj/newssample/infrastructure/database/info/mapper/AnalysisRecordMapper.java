package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.AnalysisRecordCountDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.AnalysisRecordSumDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.SourceConfigDO;

import java.util.List;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

public interface AnalysisRecordMapper {
    /**
     * 查询启用列表
     * @return
     */
    List<SourceConfigDO> listSourceConfig();

    /**
     * 根据参数进行分组求和统计
     *
     * @param sourceId
     * @return
     */
    AnalysisRecordCountDO getLatestRecord(String sourceId);

    /**
     * 根据参数进行全量分组求和统计
     * @param startTime
     * @return
     */
    List<AnalysisRecordSumDO> listRecordSum(String startTime);

}
