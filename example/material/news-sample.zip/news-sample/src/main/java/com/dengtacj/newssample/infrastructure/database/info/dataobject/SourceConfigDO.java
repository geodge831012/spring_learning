package com.dengtacj.newssample.infrastructure.database.info.dataobject;

import lombok.Data;

import java.util.Date;

/**
 * Created by Administrator on 2019/10/12 0012.
 */

@Data
public class SourceConfigDO {
    //数据源id
    private String id;

    //数据源名称
    private String sourceName;

    //是否启用
    private Integer enabled;

    //备注
    private String remark;

    //最后执行时间
    private Date lastTime;


    public String getEnableStr() {
        if (this.enabled == 0) {
            return "启用";
        }
        return "禁用";
    }
}
