package com.dengtacj.newssample.infrastructure.database.cls.dataobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Data
public class LianArticleDO {
    String id;
    String title;
    String brief;
    String content;
    Long ctime;
    int recommend;
}
