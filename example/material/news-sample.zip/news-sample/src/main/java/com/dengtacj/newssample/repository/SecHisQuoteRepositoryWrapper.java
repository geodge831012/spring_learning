package com.dengtacj.newssample.repository;

import com.dengtacj.newssample.common.utils.ProgressTimer;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by Administrator on 2019/10/23 0023.
 */

@Slf4j
@Component
public class SecHisQuoteRepositoryWrapper {


    /**
     * <dtSecCode,<date, 收盘价格>>
     */
    @Getter
    Map<String, Map<Long, Float>> secHisQuoteCache = null;

    @Getter
    ArrayList<Long> tradingDateListCache = null;


    @Autowired
    SecHisQuoteRepository secHisQuoteRepository;


    /**
     * 每天凌晨更新一次缓存
     */
    @Scheduled(cron = "0 30 0 ? * *")
    void freshCache() {
        try {
            secHisQuoteRepository.cleanTradingDateList();
            secHisQuoteRepository.getTradingDateList();

            secHisQuoteRepository.cleanSecHisQuoteMap();
            secHisQuoteRepository.getSecHisQuoteMap();
        } catch (Exception e) {
            log.error("exception:", e);
        }
    }

    public Map<String, Map<Long, Float>> getSecHisQuoteCache() {
        if(secHisQuoteCache == null) {
            secHisQuoteCache = secHisQuoteRepository.getSecHisQuoteMap();
        }
        return secHisQuoteCache;
    }

    public ArrayList<Long> getTradingDateListCache() {
        if(tradingDateListCache == null) {
            tradingDateListCache = secHisQuoteRepository.getTradingDateList();
        }
        return tradingDateListCache;
    }

}
