package com.dengtacj.newssample.service;

import com.dengtacj.newssample.client.api.NewsStatServiceI;
import com.dengtacj.newssample.client.dto.clientobject.AnalysisRecordStatCO;
import com.dengtacj.newssample.client.dto.clientobject.NewsStatDataCO;
import com.dengtacj.newssample.common.ErrorCode;
import com.dengtacj.newssample.common.MultiResponse;
import com.dengtacj.newssample.common.SingleResponse;
import com.dengtacj.newssample.repository.AnalysisRecordRepository;
import com.dengtacj.newssample.repository.NewsStatRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2019/10/11 0011.
 */

@Slf4j
@Service
public class NewsStatImpl implements NewsStatServiceI {

    @Autowired
    NewsStatRepository newsStatRepository;

    @Autowired
    AnalysisRecordRepository analysisRecordRepository;

    /**
     * 获取统计数据
     * @return
     */
    public SingleResponse<NewsStatDataCO> newsStatDataQry()  {
        try {
            return SingleResponse.of(newsStatRepository.getNewsStatDataCache());
        } catch (Exception e) {
            log.error("exception:", e);
        }
        return SingleResponse.buildFailure(ErrorCode.E_Node_unknownError);
    }

    /**
     * 获取采集统计数据
     * @return
     */
    public MultiResponse<AnalysisRecordStatCO> listAnalysisRecordStatQry(){
        try {
            return MultiResponse.ofWithoutTotal(analysisRecordRepository.getAnalysisRecordStatListCache());
        } catch (Exception e) {
            log.error("exception:", e);
        }
        return MultiResponse.buildFailure(ErrorCode.E_Node_unknownError);
    }
}
