package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsInfoDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsSourceIdDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.RecommendAnnDO;
import com.jarvis.cache.annotation.Cache;
import com.jarvis.cache.annotation.Magic;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by Administrator on 2019/9/24 0024.
 */

@Mapper
public interface NewsInfoMapper {

    /**
     * 通过ID获取资讯详情
     * @param newsId
     * @return
     */
    @Cache(expire = 3600, expireExpression = "null == #retVal ? 60: 3600", key = "'news-info:' + #args[0]")
    NewsInfoDO getByNewsId(String newsId);


    /**
     * 通过ID获取资讯详情
     * @param newsIdList
     * @return
     */
    @Cache(expire = 3600, expireExpression = "null == #retVal ? 60: 3600",
            key = "'news-info:' + #args[0]",
            magic = @Magic(key = "'news-info:' + #retVal.id", iterableArgIndex = 0))
    List<NewsInfoDO> batchGetByNewsId(@Param("newsIdList") List<String> newsIdList);

    /**
     * 获取数据源的资讯ID列表
     * @param tbSourceId 数据源类型id
     * @param createTime
     * @return
     */
    List<NewsSourceIdDO> getNewsIdBySource(@Param("tbSourceId")String tbSourceId, @Param("createTime")String createTime);


    /**
     * 获取数据源的资讯ID列表
     * @param newsType NewsTypeDO
     * @return
     */
    List<String> getNewsIdByType(int newsType);

    /**
     * 获取推荐的资讯ID
     * @return
     */
    String getRecommendNewsIdByType(@Param("type") String type, @Param("limit") int limit);

    /**
     * 获取推荐的资讯ID
     * @return
     */
    List<RecommendAnnDO> listRecommendAnn(int limit);
}
