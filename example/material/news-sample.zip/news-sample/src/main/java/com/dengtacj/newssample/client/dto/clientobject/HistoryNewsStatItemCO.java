package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

/**
 * Created by Administrator on 2019/9/26 0026.
 */

@Data
public class HistoryNewsStatItemCO {
    /**
     * 资讯抓取数量
     */
    int spiderNum;

    /**
     * 资讯去重入库数量
     */
    int afterDupNum;

    /**
     * 统计开始时间
     */
    long startTime;

    /**
     * 统计截止时间
     */
    long endTime;

}
