package com.dengtacj.newssample.client.dto.clientobject;

import lombok.Data;

import java.util.List;

/**
 * Created by Administrator on 2019/9/26 0026.
 */

@Data
public class NewsStatDataCO {

    /**
     * 今日资讯数据
     */
    TodayNewsStatCO todayNewsStat;

    /**
     * 历史资讯数据
     */
    List<HistoryNewsStatCO> historyNewsStatList;

    /**
     * 资讯标签和敏感词
     */
    List<TagNewsStatCO> tagNewsStatList;

    /**
     * 事件发现数据
     */
    List<EventDetectStatCO> eventDetectStatList;

}
