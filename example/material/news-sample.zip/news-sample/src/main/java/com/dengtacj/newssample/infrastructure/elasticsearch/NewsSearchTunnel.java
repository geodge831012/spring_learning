package com.dengtacj.newssample.infrastructure.elasticsearch;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dengtacj.newssample.common.utils.CommonUtil;
import com.dengtacj.newssample.common.utils.DateUtil;
import com.dengtacj.newssample.infrastructure.elasticsearch.dataobject.RelatedNewsDO;
import com.dengtacj.newssample.infrastructure.elasticsearch.utils.ElasticsearchAgent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Created by Administrator on 2019/10/11 0011.
 */

@Component
public class NewsSearchTunnel {

    @Value("${news.newsInfo.relatedSearchDay}")
    int relatedSearchDay;

    @Autowired
    ElasticsearchAgent elasticsearchAgent;

    public List<RelatedNewsDO> listRelatedNews(String exclude, String keyWord) {
        List<RelatedNewsDO> newsList = new LinkedList<>();
        Long timeSeconds = System.currentTimeMillis() / 1000;
        Long beginTime = timeSeconds - relatedSearchDay*24*60*60;
        String beginTimeStr = DateUtil.date2str(new Date(beginTime * 1000), "yyyy-MM-dd'T'HH:mm:ss");
        String excludeStr = CommonUtil.escapJson(exclude);
        String fmtString = "{\n" +
                "\t\"_source\": [\"id\", \"title\"],\n" +
                "\t\"query\": {\n" +
                "\t\t\"bool\": {\n" +
                "\t\t\t\"must\": {\n" +
                "\t\t\t\t\"multi_match\": {\n" +
                "\t\t\t\t\t\"query\": \"%s\",\n" +
                "\t\t\t\t\t\"fields\": [\"content\", \"title\"]\n" +
                "\t\t\t\t}\n" +
                "\t\t\t},\n" +
                "\t\t\t\"must_not\": [{\n" +
                "\t\t\t\t\t\"match\": {\n" +
                "\t\t\t\t\t\t\"title\": \"%s\"\n" +
                "\t\t\t\t\t}\n" +
                "\t\t\t\t},\n" +
                "\t\t\t\t{\n" +
                "\t\t\t\t\t\"exists\": {\n" +
                "\t\t\t\t\t\t\"field\": \"audit_reject_message\"\n" +
                "\t\t\t\t\t}\n" +
                "\t\t\t\t}\n" +
                "\t\t\t],\n" +
                "\t\t\t\"filter\": [{\n" +
                "\t\t\t\t\"range\": {\n" +
                "\t\t\t\t\t\"create_time\": {\n" +
                "\t\t\t\t\t\t\"gte\": \"%s\"\n" +
                "\t\t\t\t\t}\n" +
                "\t\t\t\t}\n" +
                "\t\t\t}]\n" +
                "\t\t}\n" +
                "\t},\n" +
                "\t\"collapse\": {\n" +
                "\t\t\"field\": \"title.keyword\"\n" +
                "\t},\n" +
                "\t\"size\": 5\n" +
                "}";
        String queryString = String.format(fmtString, keyWord, excludeStr, beginTimeStr);
        JSONObject jsonObject = elasticsearchAgent.search(queryString, "/news_info/_search");
        if(jsonObject == null) {
            return newsList;
        }
        JSONArray jsonArray = jsonObject.getJSONArray("hits");

        for (Iterator iterator = jsonArray.iterator(); iterator.hasNext();) {
            JSONObject hitsObject = (JSONObject) iterator.next();
            JSONObject sourceObject = hitsObject.getJSONObject("_source");

            RelatedNewsDO relatedNewsDO = new RelatedNewsDO();
            relatedNewsDO.setNewsId(sourceObject.getString("id"));
            relatedNewsDO.setTitle(sourceObject.getString("title"));
            newsList.add(relatedNewsDO);

        }
        return newsList;
    }
}
