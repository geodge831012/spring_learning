package com.dengtacj.newssample.infrastructure.database.info.mapper;

import com.dengtacj.newssample.infrastructure.database.info.dataobject.NewsSourceIdDO;
import com.dengtacj.newssample.infrastructure.database.info.dataobject.StockInfoDO;

import java.util.List;

/**
 * Created by Administrator on 2019/10/8 0008.
 */

public interface NewsClassMapper {
    /**
     * 获取资讯ID列表
     * @param newsClassId 资讯类型id
     * @return
     */
    public List<String> listNewsIdByClass(String newsClassId);


    /**
     * 获取所有的股票信息
     * @return
     */
    List<StockInfoDO> listAllStock();
}
